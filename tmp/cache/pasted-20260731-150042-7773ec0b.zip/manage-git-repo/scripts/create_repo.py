#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Create Repository Script for Gitee Management

This script creates a new repository in Gitee through the DevOps BFF layer.
Handles namespace_id selection with interactive prompts.
"""

import os
import sys
import argparse
import requests
from pathlib import Path
from typing import Optional, Dict, Any

_shared_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "shared"))
if _shared_dir not in sys.path:
    sys.path.insert(0, _shared_dir)

os.environ.setdefault("DEV_ASSISTANT_PROVIDER", "portal")
from _skill_auth_helper import get_token, infer_oauth_env

# 修复 Windows 环境下的编码问题（GBK 默认编码会导致 emoji/中文 UnicodeEncodeError）
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

# Add script directory to Python path for imports
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

from config_loader import ConfigLoader


class GiteeRepoCreator:
    """Client for creating Gitee repositories through DevOps BFF layer"""

    def __init__(self):
        """Initialize client with configuration"""
        self.config_loader = ConfigLoader()
        self.config = self.config_loader.load_config()

    def create_repository(self, name: str, path: Optional[str] = None, namespace_id: Optional[int] = None) -> Dict[str, Any]:
        """Create a new repository

        Args:
            name: Repository name
            path: Optional repository path (if not provided, will be generated from name)
            namespace_id: Optional namespace/group ID (0 for personal space)

        Returns:
            API response with created repository information
        """
        bff_url = self.config['bff_url']
        url = f"{bff_url}/openapi/ai-code/codeWarehouse/createRepo"

        # Build request payload
        # path: 如果没有提供，从name生成（小写+连字符）
        if path is None:
            path = name.lower().replace(" ", "-")
        payload = {
            "repoType": "GITEE",
            "name": name,
            "path": path
        }

        if namespace_id is not None:
            payload['namespaceId'] = namespace_id

        # Get access token from skill_auth SDK
        token = get_token(env=infer_oauth_env())

        headers = {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {token}'
        }

        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30, verify=False)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            # Error will be handled by caller
            raise

    def list_groups(self, search: str = "", page: int = 1, per_page: int = 20) -> Dict[str, Any]:
        """List available groups for namespace selection

        Args:
            search: Optional search keyword
            page: Page number (default: 1)
            per_page: Items per page (default: 20)

        Returns:
            API response with group list
        """
        bff_url = self.config['bff_url']
        url = f"{bff_url}/openapi/ai-code/codeWarehouse/pageGroupsBySearch"

        payload = {
            "repoType": "GITEE",
            "currentPage": page,
            "pageSize": per_page,
            "search": search
        }

        # Get access token from skill_auth SDK
        token = get_token(env=infer_oauth_env())

        headers = {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {token}'
        }

        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30, verify=False)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            # Error will be handled by caller
            raise


MAX_INPUT_RETRIES = 5


def select_namespace_interactive(creator: GiteeRepoCreator) -> Optional[int]:
    """Interactive namespace selection

    Returns:
        Selected namespace_id or 0 for personal space
    """
    print("\n" + "=" * 60)
    print("  仓库组选择")
    print("=" * 60)

    for attempt in range(MAX_INPUT_RETRIES):
        print("\n选项:")
        print("  1. 不使用仓库组，创建在个人空间")
        print("  2. 查看并选择仓库组")
        print("  0. 取消")

        choice = input("\n请选择 [0-2]: ").strip()

        if choice == '0':
            return None
        elif choice == '1':
            return 0
        elif choice == '2':
            return search_and_select_group(creator)
        else:
            remaining = MAX_INPUT_RETRIES - attempt - 1
            if remaining > 0:
                print(f"无效选择，请重新输入（剩余 {remaining} 次机会）")
            else:
                print("无效输入次数过多，已自动取消")
    return None


def search_and_select_group(creator: GiteeRepoCreator, _search_depth: int = 0) -> Optional[int]:
    """Search and select a group interactively

    Returns:
        Selected namespace_id or None if cancelled
    """
    max_search_depth = 3
    if _search_depth >= max_search_depth:
        print("重新搜索次数过多，已自动取消")
        return None

    search = input("\n请输入搜索关键字 (留空显示所有): ").strip()

    # Fetch first page
    result = creator.list_groups(search=search, page=1, per_page=10)

    if result.get('code') != 0:
        print(f"Error: {result.get('message')}")
        return None

    data = result.get('data')
    if not data or not data.get('groupVOPage'):
        print("未找到仓库组")
        return None

    page_data = data['groupVOPage']
    groups = page_data.get('data', [])
    total = page_data.get('total', 0)

    if not groups:
        print("未找到仓库组")
        return None

    print(f"\n找到 {total} 个仓库组 (显示前 {len(groups)} 个):")
    print("-" * 60)

    for idx, group in enumerate(groups, 1):
        print(f"  {idx}. {group['name']} (ID: {group['id']})")
        if group.get('description'):
            print(f"     描述: {group['description']}")

    print("-" * 60)

    for attempt in range(MAX_INPUT_RETRIES):
        selection = input(f"\n请选择 [1-{len(groups)}]，或输入0重新搜索: ").strip()

        if selection == '0':
            return search_and_select_group(creator, _search_depth + 1)

        try:
            idx = int(selection)
            if 1 <= idx <= len(groups):
                selected_group = groups[idx - 1]
                print(f"\n已选择: {selected_group['name']} (ID: {selected_group['id']})")
                return int(selected_group['id'])
            else:
                remaining = MAX_INPUT_RETRIES - attempt - 1
                if remaining > 0:
                    print(f"请输入 1-{len(groups)} 之间的数字（剩余 {remaining} 次机会）")
                else:
                    print("无效输入次数过多，已自动取消")
        except ValueError:
            remaining = MAX_INPUT_RETRIES - attempt - 1
            if remaining > 0:
                print(f"无效输入，请输入数字（剩余 {remaining} 次机会）")
            else:
                print("无效输入次数过多，已自动取消")
    return None


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Create a new Gitee repository',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create with interactive namespace selection
  python %(prog)s --name "my-project"

  # Create with custom path (for Chinese names)
  python %(prog)s --name "从skill创建的仓库" --path "create-repo-from-skill"

  # Create in personal space directly
  python %(prog)s --name "my-project" --namespace-id 0

  # Create in specific group
  python %(prog)s --name "my-project" --namespace-id 12345
        """
    )

    parser.add_argument('--name', required=True, help='Repository name')
    parser.add_argument('--path', help='Repository path (optional, auto-generated from name if not provided)')
    parser.add_argument('--namespace-id', type=int, help='Namespace ID (0 for personal space)')

    args = parser.parse_args()

    try:
        creator = GiteeRepoCreator()

        # Determine namespace_id
        namespace_id = args.namespace_id
        if namespace_id is None:
            namespace_id = select_namespace_interactive(creator)
            if namespace_id is None:
                print("\n已取消")
                sys.exit(0)

        # Create repository
        result = creator.create_repository(args.name, args.path, namespace_id)

        # 检查响应：success=true 或 code=200 都表示成功
        if not (result.get('success') or str(result.get('code')) == '200'):
            print(f"\n✗ 仓库创建失败", file=sys.stderr)
            print(f"错误: {result.get('message', 'Unknown error')}", file=sys.stderr)
            sys.exit(1)

        # Success - display repository information
        print(f"\n✓ 仓库创建成功！")
        print(f"  名称: {args.name}")
        print(f"  路径: {args.path}")

        # Display additional info if available in response
        if result.get('data'):
            data = result['data']
            if data.get('webUrl'):
                print(f"  URL: {data['webUrl']}")
            if data.get('id'):
                print(f"  ID: {data['id']}")
        else:
            # 即使没有 data 字段，也显示基本信息
            print(f"  仓库已创建，名称: {args.name}, 路径: {args.path}")

    except ValueError as e:
        print(f"✗ 配置错误: {e}", file=sys.stderr)
        sys.exit(1)
    except requests.exceptions.RequestException as e:
        print(f"✗ 网络请求失败: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"✗ 未知错误: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
