#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Query Commits Script for Gitee Management

Supports two operations via subcommands:
  - list:   List commits of a repository (supports pagination and filters)
  - detail: Query detailed information of a specific commit

Users provide a repo name (or search keyword). The script resolves the repo URL
automatically via the getRepoList API.
"""

import os
import sys
import json
import argparse
import requests
from typing import Optional, Dict, Any
from config_loader import ConfigLoader

_shared_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "shared"))
if _shared_dir not in sys.path:
    sys.path.insert(0, _shared_dir)

os.environ.setdefault("DEV_ASSISTANT_PROVIDER", "portal")
from _skill_auth_helper import get_token, infer_oauth_env

# 修复 Windows 环境下的编码问题（GBK 默认编码会导致 emoji/中文 UnicodeEncodeError）
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")


class GiteeCommitQuery:
    """Client for querying Gitee commits through the DevOps BFF layer"""

    def __init__(self):
        self.config_loader = ConfigLoader()
        self.config = self.config_loader.load_config()

    def _headers(self) -> Dict[str, str]:
        token = get_token(env=infer_oauth_env())
        return {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {token}'
        }

    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.config['bff_url']}/openapi/ai-code{path}"
        resp = requests.post(url, json=payload, headers=self._headers(), timeout=30, verify=False)
        resp.raise_for_status()
        return resp.json()

    def search_repos(self, keyword: str, page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        """Search repositories by keyword, returns the raw API response."""
        return self._post("/repo/getRepoList", {
            "repoType": "GITEE",
            "search": keyword,
            "hasStat": 0,
            "currentPage": page,
            "pageSize": page_size,
        })

    def list_commits(self, repo_url: str, branch: str = "", search: str = "",
                     from_date: str = "", to_date: str = "", user_name: str = "",
                     page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        """List commits with optional filters."""
        payload = {
            "repoType": "gitee",
            "repoUrl": repo_url,
            "currentPage": page,
            "pageSize": page_size,
        }
        if branch:
            payload["branch"] = branch
        if search:
            payload["search"] = search
        if from_date:
            payload["fromDate"] = from_date
        if to_date:
            payload["toDate"] = to_date
        if user_name:
            payload["userName"] = user_name
        return self._post("/repo/getRepoCommitList", payload)

    def get_commit_detail(self, repo_url: str, commit_id: str) -> Dict[str, Any]:
        """Get detailed information of a specific commit."""
        return self._post("/codeWarehouse/queryCommitDetail", {
            "repoType": "gitee",
            "repoUrl": repo_url,
            "commitId": commit_id,
        })


# ---- helpers ----

def resolve_repo_info(manager: GiteeCommitQuery, search: Optional[str], repo_url: Optional[str]) -> Optional[dict]:
    """Resolve a repo URL from either a direct URL or a search keyword.

    Returns a dict with 'url' and 'id' keys, or None if not found / user needs to choose.
    When multiple repos match, prints them as JSON for Claude to present to the user.
    """
    if repo_url:
        return {"url": repo_url, "id": None}

    if not search:
        print(json.dumps({"error": "Either --repo-search or --repo-url is required"}, ensure_ascii=False))
        return None

    result = manager.search_repos(search)
    success = result.get('success') or str(result.get('code')) == '200'
    if not success:
        print(json.dumps({"error": result.get('message', 'Search failed')}, ensure_ascii=False))
        return None

    data = result.get('data')
    repos = []
    if isinstance(data, dict):
        repo_vo_page = data.get('repoVOPage', {})
        if isinstance(repo_vo_page, dict) and 'data' in repo_vo_page:
            repos = repo_vo_page.get('data', [])
        else:
            repos = data.get('data', [])
    elif isinstance(data, list):
        repos = data

    if not repos:
        print(json.dumps({"error": f"No repositories found for keyword '{search}'"}, ensure_ascii=False))
        return None

    if len(repos) == 1:
        return {
            "url": repos[0].get('httpUrl'),
            "id": repos[0].get('id')
        }

    # Multiple matches: output list for Claude to present
    repo_list = []
    for idx, r in enumerate(repos, 1):
        repo_list.append({
            "index": idx,
            "id": r.get('id'),
            "name": r.get('name'),
            "path": r.get('path'),
            "httpUrl": r.get('httpUrl'),
            "description": r.get('description', ''),
        })
    print(json.dumps({
        "multiple_repos": repo_list,
        "message": f"Found {len(repo_list)} repositories. Please select one by providing --repo-url with the httpUrl value.",
    }, ensure_ascii=False, indent=2))
    return None


# ---- subcommands ----

def cmd_list(args):
    manager = GiteeCommitQuery()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    result = manager.list_commits(
        repo_url=repo_info['url'],
        branch=args.branch or "",
        search=args.search or "",
        from_date=args.from_date or "",
        to_date=args.to_date or "",
        user_name=args.user_name or "",
        page=args.page,
        page_size=args.page_size,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_detail(args):
    manager = GiteeCommitQuery()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    if not args.commit_id:
        print(json.dumps({"error": "--commit-id is required for detail query"}, ensure_ascii=False))
        sys.exit(1)

    result = manager.get_commit_detail(
        repo_url=repo_info['url'],
        commit_id=args.commit_id,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


# ---- main ----

def main():
    parser = argparse.ArgumentParser(
        description='Query Gitee repository commits',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List commits of a repository (search by keyword)
  python %(prog)s list --repo-search "my-project"

  # List commits (direct repo URL)
  python %(prog)s list --repo-url "https://gitee.com/org/my-project"

  # List commits with filters and pagination
  python %(prog)s list --repo-search "my-project" --branch "master" --from-date "2026-03-01" --to-date "2026-03-20" --page 1 --page-size 10

  # Query commit detail
  python %(prog)s detail --repo-search "my-project" --commit-id "abc123def456"

  # Query commit detail with direct repo URL
  python %(prog)s detail --repo-url "https://gitee.com/org/my-project" --commit-id "abc123def456"
        """,
    )

    subparsers = parser.add_subparsers(dest='command', help='Operation to perform')
    subparsers.required = True

    # list subcommand
    sp_list = subparsers.add_parser('list', help='List commits of a repository')
    repo_group = sp_list.add_mutually_exclusive_group(required=True)
    repo_group.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_list.add_argument('--branch', help='Filter by branch name')
    sp_list.add_argument('--search', help='Fuzzy filter on commit message')
    sp_list.add_argument('--from-date', help='Start date filter (format: YYYY-MM-DD)')
    sp_list.add_argument('--to-date', help='End date filter (format: YYYY-MM-DD)')
    sp_list.add_argument('--user-name', help='Filter by committer username')
    sp_list.add_argument('--page', type=int, default=1, help='Page number (default: 1)')
    sp_list.add_argument('--page-size', type=int, default=20, help='Page size (default: 20)')

    # detail subcommand
    sp_detail = subparsers.add_parser('detail', help='Query detailed commit information')
    repo_group2 = sp_detail.add_mutually_exclusive_group(required=True)
    repo_group2.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group2.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_detail.add_argument('--commit-id', required=True, help='Commit SHA/ID to query')

    args = parser.parse_args()

    try:
        if args.command == 'list':
            cmd_list(args)
        elif args.command == 'detail':
            cmd_detail(args)
    except requests.exceptions.RequestException as e:
        print(json.dumps({"error": f"HTTP request failed: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"Network request failed: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(json.dumps({"error": f"Configuration error: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"error": f"Unexpected error: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"Unexpected error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
