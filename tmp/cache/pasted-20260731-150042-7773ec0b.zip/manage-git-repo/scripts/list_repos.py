#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
List Repositories Script for Gitee Management

This script queries and lists repositories from Gitee through the DevOps BFF layer.
Supports keyword search and pagination.
"""

import os
import sys
import argparse
import requests
from pathlib import Path
from typing import Optional, Dict, Any, List
from datetime import datetime
from config_loader import ConfigLoader

_shared_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "shared"))
if _shared_dir not in sys.path:
    sys.path.insert(0, _shared_dir)

os.environ.setdefault("DEV_ASSISTANT_PROVIDER", "portal")
from _skill_auth_helper import get_token, infer_oauth_env

# 修复 Windows 环境下的编码问题（GBK 默认编码会导致 emoji/中文 UnicodeEncodeError）
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")


class GiteeRepoLister:
    """Client for listing Gitee repositories through DevOps BFF layer"""

    def __init__(self):
        """Initialize client with configuration"""
        self.config_loader = ConfigLoader()
        self.config = self.config_loader.load_config()

    # Valid values for the type parameter
    VALID_TYPES = ("all", "created", "participated", "favorites", "inner_source")

    def list_repositories(
        self,
        search: str = "",
        has_stat: int = 0,
        page: int = 1,
        page_size: int = 20,
        type: Optional[str] = None
    ) -> Dict[str, Any]:
        """List repositories with optional filtering

        Args:
            search: Optional search keyword for fuzzy search on repository name/path
            has_stat: Whether to return code statistics (0: no, 1: yes)
            page: Page number (default: 1)
            page_size: Items per page (default: 20)
            type: Repository filter type. One of:
                  "all"           - 全部
                  "created"       - 我拥有的
                  "participated"  - 我参与的
                  "favorites"     - 我的星标
                  "inner_source"  - 内部公开

        Returns:
            API response with repository list
        """
        if type is not None and type not in self.VALID_TYPES:
            raise ValueError(
                f"Invalid type '{type}'. Must be one of: {', '.join(self.VALID_TYPES)}"
            )

        bff_url = self.config['bff_url']
        url = f"{bff_url}/openapi/ai-code/repo/getRepoList"

        payload = {
            "repoType": "GITEE",
            "search": search,
            "hasStat": has_stat,
            "currentPage": page,
            "pageSize": page_size
        }
        if type is not None:
            payload["type"] = type

        # Get access token from skill_auth SDK
        token = get_token(env=infer_oauth_env())

        headers = {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {token}'
        }

        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30, verify=False)
            return response.json()
        except requests.exceptions.RequestException as e:
            # Error will be handled by caller
            raise


def format_timestamp(timestamp_str: Optional[str]) -> str:
    """Format ISO timestamp to readable string

    Args:
        timestamp_str: ISO 8601 timestamp string

    Returns:
        Formatted date string or "N/A" if None
    """
    if not timestamp_str:
        return "N/A"

    try:
        dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
        return dt.strftime('%Y-%m-%d %H:%M')
    except:
        return timestamp_str


def print_repositories(result: Dict[str, Any], show_details: bool = False):
    """Print repository list in formatted table

    Args:
        result: API response data
        show_details: Whether to show detailed information
    """
    # Check if request was successful
    if not result.get('success') and str(result.get('code')) != '200':
        print(f"Error: {result.get('message', 'Unknown error')}", file=sys.stderr)
        return

    data = result.get('data')
    if not data or not data.get('repoVOPage'):
        print("No repository data found")
        return

    page_data = data['repoVOPage']
    repos = page_data.get('data', [])
    total = page_data.get('total', 0)
    current_page = page_data.get('currentPage', 1)
    page_size = page_data.get('pageSize', 20)

    if not repos:
        print("No repositories found")
        return

    # Print summary
    print(f"Found {total} repositories (Page {current_page}, showing {len(repos)} items):")
    print("=" * 80)

    # Print each repository
    for idx, repo in enumerate(repos, 1):
        print(f"\n{idx}. {repo.get('name', 'N/A')}")
        print(f"   Path: {repo.get('path', 'N/A')}")
        print(f"   ID: {repo.get('id', 'N/A')}")

        if show_details:
            if repo.get('description'):
                print(f"   Description: {repo['description']}")
            if repo.get('httpUrl'):
                print(f"   URL: {repo['httpUrl']}")
            if repo.get('ownerName'):
                print(f"   Owner: {repo['ownerName']}")
            if repo.get('createdTime'):
                formatted_time = format_timestamp(repo['createdTime'])
                print(f"   Created: {formatted_time}")
            if repo.get('commitNum') is not None:
                print(f"   Commits: {repo['commitNum']}")
            if repo.get('totalLines') is not None:
                print(f"   Total Lines: {repo['totalLines']}")

    print("=" * 80)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='List Gitee repositories',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List all repositories
  python %(prog)s

  # Search repositories by keyword
  python %(prog)s --search "awesome"

  # Filter by type: my owned repositories
  python %(prog)s --type created

  # Filter by type: repositories I participated in
  python %(prog)s --type participated

  # Filter by type: starred repositories
  python %(prog)s --type favorites

  # Filter by type: inner-source (internal public) repositories
  python %(prog)s --type inner_source

  # Combine type filter with search
  python %(prog)s --type created --search "awesome"

  # List with code statistics
  python %(prog)s --has-stat

  # Show detailed information
  python %(prog)s --show-details

  # Second page with 10 items per page
  python %(prog)s --page 2 --page-size 10

  # Output raw JSON
  python %(prog)s --json
        """
    )

    parser.add_argument('--search', help='Search keyword for fuzzy search on repository name/path')
    parser.add_argument('--type',
                       choices=GiteeRepoLister.VALID_TYPES,
                       metavar='TYPE',
                       help=(
                           'Filter repositories by type. '
                           'Choices: all（全部）, created（我拥有的）, '
                           'participated（我参与的）, favorites（我的星标）, '
                           'inner_source（内部公开）'
                       ))
    parser.add_argument('--has-stat', action='store_true',
                       help='Include code statistics in response')
    parser.add_argument('--page', type=int, default=1,
                       help='Page number (default: 1)')
    parser.add_argument('--page-size', type=int, default=20,
                       help='Items per page (default: 20)')
    parser.add_argument('--show-details', action='store_true',
                       help='Show detailed information including URLs and timestamps')
    parser.add_argument('--json', action='store_true',
                       help='Output raw JSON instead of formatted table')

    args = parser.parse_args()

    try:
        lister = GiteeRepoLister()

        # Query repositories
        result = lister.list_repositories(
            search=args.search or "",
            has_stat=1 if args.has_stat else 0,
            page=args.page,
            page_size=args.page_size,
            type=args.type
        )

        if args.json:
            # Output raw JSON
            import json
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            # Print formatted table
            print_repositories(result, show_details=args.show_details)

    except ValueError as e:
        print(f"✗ 配置错误: {e}", file=sys.stderr)
        sys.exit(1)
    except requests.exceptions.RequestException as e:
        print(f"✗ 网络请求失败: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"✗ 未知错误: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
