#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Manage Project Members Script for Gitee Management

Supports four operations via subcommands:
  - list:      List members of a repository
  - add:       Add a new member to a repository (fails if member exists)
  - update:    Add or update a member's role/permissions (no existence check)
  - delete:    Remove a member from a repository

Users provide a repo name (or search keyword) and member domain account.
The script resolves the repo URL automatically via the getRepoList API.
"""

import os
import sys
import json
import argparse
import requests
from typing import Optional, Dict, Any, List
from config_loader import ConfigLoader

_shared_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "shared"))
if _shared_dir not in sys.path:
    sys.path.insert(0, _shared_dir)

os.environ.setdefault("DEV_ASSISTANT_PROVIDER", "portal")
from _skill_auth_helper import get_token, infer_oauth_env

# 修复 Windows 环境下的编码问题（GBK 默认编码会导致 emoji/中文 UnicodeEncodeError）
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

ROLE_ACCESS_LEVEL = {
    "guest": 2,
    "collaborator": 4,
    "configurator": 6,
    "admin": 8,
}

ACCESS_LEVEL_ROLE = {v: k for k, v in ROLE_ACCESS_LEVEL.items()}


class GiteeMemberManager:
    """Client for managing Gitee project members through the DevOps BFF layer"""

    def __init__(self):
        self.config_loader = ConfigLoader()
        self.config = self.config_loader.load_config()

    def _headers(self) -> Dict[str, str]:
        # Get access token from skill_auth SDK
        token = get_token(env=infer_oauth_env())
        return {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {token}'
        }

    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.config['bff_url']}/openapi/ai-code{path}"
        resp = requests.post(url, json=payload, headers=self._headers(), timeout=30, verify=False)
        resp.raise_for_status()
        return resp.json()

    def _delete(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        # 使用 POST 代替 DELETE，因为后端接口只支持 POST
        url = f"{self.config['bff_url']}/openapi/ai-code{path}"
        resp = requests.post(url, json=payload, headers=self._headers(), timeout=30, verify=False)
        resp.raise_for_status()
        return resp.json()

    # ---- repo search ----

    def search_repos(self, keyword: str, page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        """Search repositories by keyword, returns the raw API response."""
        return self._post("/repo/getRepoList", {
            "repoType": "GITEE",
            "search": keyword,
            "hasStat": 0,
            "currentPage": page,
            "pageSize": page_size,
        })

    # ---- member operations ----

    def list_members(self, repo_url: str, project_id: int = None) -> Dict[str, Any]:
        payload = {
            "repoType": "GITEE",
            "repoUrl": repo_url,
        }
        if project_id is not None:
            payload["projectId"] = project_id
        return self._post("/repo/getProjectMembers", payload)

    def add_member(self, repo_url: str, member_username: str, access_level: int, user_id: int = None, project_id: int = None) -> Dict[str, Any]:
        payload = {
            "repoType": "GITEE",
            "repoUrl": repo_url,
            "memberUserName": member_username,
            "accessLevel": access_level,
        }
        if user_id is not None:
            payload["userId"] = user_id
        if project_id is not None:
            payload["projectId"] = project_id
        return self._post("/repo/addOrUpdateProjectMember", payload)

    def search_user(self, query: str) -> Dict[str, Any]:
        """Search for a Gitee user by domain account/username"""
        # Use GET request with query parameters
        bff_url = self.config['bff_url']
        url = f"{bff_url}/openapi/ai-code/users"

        params = {
            "query": query,
            "repoType": "GITEE"
        }

        # Get access token from skill_auth SDK
        token = get_token(env=infer_oauth_env())
        headers = {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {token}'
        }

        response = requests.get(url, params=params, headers=headers, timeout=30, verify=False)
        response.raise_for_status()
        return response.json()

    def delete_member(self, repo_url: str, user_id: int, project_id: int = None) -> Dict[str, Any]:
        payload = {
            "repoType": "GITEE",
            "repoUrl": repo_url,
            "userId": user_id,
        }
        if project_id is not None:
            payload["projectId"] = project_id
        return self._delete("/repo/deleteProjectMember", payload)


# ---- helpers ----

def resolve_repo_info(manager: GiteeMemberManager, search: Optional[str], repo_url: Optional[str]) -> Optional[dict]:
    """Resolve a repo URL and ID from either a direct URL or a search keyword.

    Returns a dict with 'url' and 'id' keys, or None if not found / user needs to choose.
    When multiple repos match, prints them as JSON for Claude to present to the user.
    """
    if repo_url:
        # When direct URL is provided, we don't have the project ID
        # Let backend handle it by querying the project details
        return {"url": repo_url, "id": None}

    if not search:
        print(json.dumps({"error": "Either --repo-search or --repo-url is required"}, ensure_ascii=False))
        return None

    result = manager.search_repos(search)
    success = result.get('success') or str(result.get('code')) == '200'
    if not success:
        print(json.dumps({"error": result.get('message', 'Search failed')}, ensure_ascii=False))
        return None

    data = result.get('data')
    repos = []
    if isinstance(data, dict):
        # Handle nested structure: data.repoVOPage.data (Gitee API response)
        repo_vo_page = data.get('repoVOPage', {})
        if isinstance(repo_vo_page, dict) and 'data' in repo_vo_page:
            repos = repo_vo_page.get('data', [])
        else:
            # Fallback to data.data (simple structure)
            repos = data.get('data', [])
    elif isinstance(data, list):
        repos = data

    if not repos:
        print(json.dumps({"error": f"No repositories found for keyword '{search}'"}, ensure_ascii=False))
        return None

    if len(repos) == 1:
        return {
            "url": repos[0].get('httpUrl'),
            "id": repos[0].get('id')
        }

    # Multiple matches: output list for Claude to present
    repo_list = []
    for idx, r in enumerate(repos, 1):
        repo_list.append({
            "index": idx,
            "id": r.get('id'),
            "name": r.get('name'),
            "path": r.get('path'),
            "httpUrl": r.get('httpUrl'),
            "description": r.get('description', ''),
        })
    print(json.dumps({
        "multiple_repos": repo_list,
        "message": f"Found {len(repo_list)} repositories. Please select one by providing --repo-url with the httpUrl value.",
    }, ensure_ascii=False, indent=2))
    return None


def resolve_repo_url(manager: GiteeMemberManager, search: Optional[str], repo_url: Optional[str]) -> Optional[str]:
    """Resolve a repo URL from either a direct URL or a search keyword.

    Returns the repo httpUrl, or None if not found / user needs to choose.
    When multiple repos match, prints them as JSON for Claude to present to the user.
    """
    repo_info = resolve_repo_info(manager, search, repo_url)
    if repo_info:
        return repo_info['url']
    return None


def find_member_id(members: list, username: str) -> Optional[int]:
    """Find a member's id by username or login from the member list."""
    for m in members:
        if m.get('username') == username or m.get('login') == username:
            return m.get('id')
    return None


# ---- subcommands ----

def cmd_list(args):
    manager = GiteeMemberManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    # Use provided project_id if available, otherwise use the one from search
    project_id = getattr(args, 'project_id', None) or repo_info['id']

    result = manager.list_members(repo_info['url'], project_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_add(args):
    """Add a new member to a repository. Fails if the member already exists."""
    if not args.member:
        print(json.dumps({"error": "--member is required for add"}, ensure_ascii=False))
        sys.exit(1)

    role = args.role or "collaborator"
    if role not in ROLE_ACCESS_LEVEL:
        print(json.dumps({
            "error": f"Invalid role '{role}'",
            "valid_roles": list(ROLE_ACCESS_LEVEL.keys()),
        }, ensure_ascii=False))
        sys.exit(1)

    access_level = ROLE_ACCESS_LEVEL[role]

    manager = GiteeMemberManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    # Use provided project_id if available, otherwise use the one from search
    project_id = getattr(args, 'project_id', None) or repo_info['id']
    # Use provided user_id if available
    user_id = getattr(args, 'user_id', None)

    # Check if member already exists - fail if they do
    members_result = manager.list_members(repo_info['url'], project_id)
    member_exists = False
    current_role = None

    if members_result.get('success') or str(members_result.get('code')) == '200':
        for m in members_result.get('data', []):
            if m.get('username') == args.member or m.get('login') == args.member:
                member_exists = True
                current_role = ACCESS_LEVEL_ROLE.get(m.get('accessLevel'), str(m.get('accessLevel')))
                break

    if member_exists:
        print(json.dumps({
            "error": f"Member '{args.member}' already exists in the repository with role '{current_role}'",
            "suggestion": f"Use the 'update' command to change the member's role: python manage_members.py update --repo-search <repo> --member '{args.member}' --role <role>",
            "member": args.member,
            "current_role": current_role
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    # Add the new member
    result = manager.add_member(repo_info['url'], args.member, access_level, user_id, project_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_update(args):
    """Add or update a member's role/permissions. Directly calls addOrUpdateProjectMember."""
    if not args.member:
        print(json.dumps({"error": "--member is required for update"}, ensure_ascii=False))
        sys.exit(1)

    role = args.role or "collaborator"
    if role not in ROLE_ACCESS_LEVEL:
        print(json.dumps({
            "error": f"Invalid role '{role}'",
            "valid_roles": list(ROLE_ACCESS_LEVEL.keys()),
        }, ensure_ascii=False))
        sys.exit(1)

    access_level = ROLE_ACCESS_LEVEL[role]

    manager = GiteeMemberManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    project_id = getattr(args, 'project_id', None) or repo_info['id']
    user_id = getattr(args, 'user_id', None)

    result = manager.add_member(repo_info['url'], args.member, access_level, user_id, project_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_delete(args):
    if not args.member:
        print(json.dumps({"error": "--member is required for delete"}, ensure_ascii=False))
        sys.exit(1)

    manager = GiteeMemberManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    # Use provided project_id if available, otherwise use the one from search
    project_id = getattr(args, 'project_id', None) or repo_info['id']

    # Look up userId from the member list
    members_result = manager.list_members(repo_info['url'], project_id)
    success = members_result.get('success') or str(members_result.get('code')) == '200'
    if not success:
        print(json.dumps({"error": "Failed to list members: " + members_result.get('message', '')}, ensure_ascii=False))
        sys.exit(1)

    members = members_result.get('data', [])
    user_id = find_member_id(members, args.member)
    if user_id is None:
        print(json.dumps({
            "error": f"Member '{args.member}' not found in this repository",
            "current_members": [m.get('username') or m.get('login') for m in members],
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    result = manager.delete_member(repo_info['url'], user_id, project_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))


# ---- main ----

def main():
    parser = argparse.ArgumentParser(
        description='Manage Gitee project members',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List members of a repository (search by keyword)
  python %(prog)s list --repo-search "my-project"

  # List members (direct repo URL)
  python %(prog)s list --repo-url "https://gitee.com/org/my-project"

  # List members with project ID (recommended)
  python %(prog)s list --repo-url "https://gitee.com/org/my-project" --project-id 474190

  # Add a new member with default role (collaborator)
  python %(prog)s add --repo-search "my-project" --member "zhangsan"

  # Add a new member as admin
  python %(prog)s add --repo-search "my-project" --member "zhangsan" --role admin

  # Update a member's role (adds if not exists, updates if exists)
  python %(prog)s update --repo-search "my-project" --member "zhangsan" --role configurator

  # Delete a member with project ID (recommended)
  python %(prog)s delete --repo-search "my-project" --project-id 12345 --member "zhangsan"

Roles:
  guest             - Access level 2 (visitor)
  collaborator      - Access level 4 (default)
  configurator      - Access level 6
  admin             - Access level 8
        """,
    )

    subparsers = parser.add_subparsers(dest='command', help='Operation to perform')
    subparsers.required = True

    # shared args
    for name, help_text in [
        ('list', 'List members of a repository'),
        ('add', 'Add a new member to a repository'),
        ('update', 'Add or update a member\'s role/permissions'),
        ('delete', 'Remove a member from a repository'),
    ]:
        sp = subparsers.add_parser(name, help=help_text)
        repo_group = sp.add_mutually_exclusive_group(required=True)
        repo_group.add_argument('--repo-search', help='Search keyword to find the repository')
        repo_group.add_argument('--repo-url', help='Direct repository URL (skips search)')

        if name in ('add', 'update', 'delete'):
            sp.add_argument('--member', required=True, help="Member's domain account (username)")

        if name == 'list':
            sp.add_argument('--project-id', type=int, help='Project numeric ID (optional, more reliable)')

        if name in ('add', 'update'):
            sp.add_argument('--role', default='collaborator',
                            choices=list(ROLE_ACCESS_LEVEL.keys()),
                            help='Access role (default: collaborator)')
            sp.add_argument('--project-id', type=int, help='Project numeric ID (optional, more reliable)')
            sp.add_argument('--user-id', type=int, help='Member user ID (optional, for adding by user ID)')

        if name == 'delete':
            sp.add_argument('--project-id', type=int, help='Project numeric ID (optional, more reliable)')

    args = parser.parse_args()

    try:
        if args.command == 'list':
            cmd_list(args)
        elif args.command == 'add':
            cmd_add(args)
        elif args.command == 'update':
            cmd_update(args)
        elif args.command == 'delete':
            cmd_delete(args)
    except requests.exceptions.RequestException as e:
        print(json.dumps({"error": f"HTTP request failed: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"✗ 网络请求失败: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(json.dumps({"error": f"Configuration error: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"✗ 配置错误: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"error": f"Unexpected error: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"✗ 未知错误: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
