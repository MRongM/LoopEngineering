#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Manage PRs Script for Gitee Management

Supports operations via subcommands:
  - create: Create a Pull Request (Merge Request)
  - close:  Close a Pull Request (Merge Request)
  - list:   List Pull Requests
  - detail: Get Pull Request detail
  - accept: Accept/Merge a Pull Request
  - update: Update a Pull Request

Users provide a repo name (or search keyword). The script resolves the repo URL
automatically via the getRepoList API.
"""

import os
import sys
import json
import argparse
import requests
from typing import Optional, Dict, Any
from config_loader import ConfigLoader

_shared_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "shared"))
if _shared_dir not in sys.path:
    sys.path.insert(0, _shared_dir)

os.environ.setdefault("DEV_ASSISTANT_PROVIDER", "portal")
from _skill_auth_helper import get_token, infer_oauth_env

# 修复 Windows 环境下的编码问题（GBK 默认编码会导致 emoji/中文 UnicodeEncodeError）
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")


class GiteePRManager:
    """Client for managing Gitee Pull Requests through the DevOps BFF layer"""

    def __init__(self):
        self.config_loader = ConfigLoader()
        self.config = self.config_loader.load_config()

    def _headers(self) -> Dict[str, str]:
        token = get_token(env=infer_oauth_env())
        return {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {token}'
        }

    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.config['bff_url']}/openapi/ai-code{path}"
        resp = requests.post(url, json=payload, headers=self._headers(), timeout=30, verify=False)
        resp.raise_for_status()
        return resp.json()

    def search_repos(self, keyword: str, page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        """Search repositories by keyword, returns the raw API response."""
        return self._post("/repo/getRepoList", {
            "repoType": "GITEE",
            "search": keyword,
            "hasStat": 0,
            "currentPage": page,
            "pageSize": page_size,
        })

    def create_pr(self, repo_url: str, source_branch: str, target_branch: str,
                  title: str, description: str = "", user: str = "") -> Dict[str, Any]:
        """Create a Pull Request (Merge Request)."""
        payload = {
            "repoType": "gitee",
            "repoUrl": repo_url,
            "sourceBranch": source_branch,
            "targetBranch": target_branch,
            "title": title,
        }
        if description:
            payload["description"] = description
        if user:
            payload["user"] = user
        return self._post("/pr/mergeRequest", payload)

    def close_pr(self, repo_url: str, merge_request_iid: int, user: str = "") -> Dict[str, Any]:
        """Close a Pull Request (Merge Request)."""
        payload = {
            "repoType": "gitee",
            "repoUrl": repo_url,
            "mergeRequestIid": merge_request_iid,
        }
        if user:
            payload["user"] = user
        return self._post("/pr/closeMergeRequest", payload)

    def list_prs(self, repo_url: str, state: str = "", source_branch: str = "",
                 target_branch: str = "", search: str = "", order_by: str = "",
                 sort: str = "", page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        """List Pull Requests with optional filters."""
        payload = {
            "repoType": "gitee",
            "repoUrl": repo_url,
            "currentPage": page,
            "pageSize": page_size,
        }
        if state:
            payload["state"] = state
        if source_branch:
            payload["sourceBranch"] = source_branch
        if target_branch:
            payload["targetBranch"] = target_branch
        if search:
            payload["search"] = search
        if order_by:
            payload["orderBy"] = order_by
        if sort:
            payload["sort"] = sort
        return self._post("/pr/getMergeRequestList", payload)

    def get_pr_detail(self, repo_url: str, merge_request_iid: int) -> Dict[str, Any]:
        """Get Pull Request detail."""
        payload = {
            "repoType": "gitee",
            "repoUrl": repo_url,
            "mergeRequestIid": merge_request_iid,
        }
        return self._post("/pr/getMergeRequest", payload)

    def accept_pr(self, repo_url: str, merge_request_iid: int,
                  merge_commit_message: str = "", squash_commit_message: str = "",
                  squash: bool = False) -> Dict[str, Any]:
        """Accept/Merge a Pull Request."""
        payload = {
            "repoType": "gitee",
            "repoUrl": repo_url,
            "mergeRequestIid": merge_request_iid,
        }
        if merge_commit_message:
            payload["mergeCommitMessage"] = merge_commit_message
        if squash_commit_message:
            payload["squashCommitMessage"] = squash_commit_message
        if squash:
            payload["squash"] = squash
        return self._post("/pr/acceptMergeRequest", payload)

    def update_pr(self, repo_url: str, merge_request_iid: int, state_event: str,
                  title: str = "", description: str = "",
                  ) -> Dict[str, Any]:
        """Update a Pull Request."""
        payload = {
            "repoType": "gitee",
            "repoUrl": repo_url,
            "mergeRequestIid": merge_request_iid,
            "stateEvent": state_event,
        }
        if title:
            payload["title"] = title
        if description:
            payload["description"] = description
        return self._post("/pr/updateMergeRequest", payload)


# ---- helpers ----

def resolve_repo_info(manager: GiteePRManager, search: Optional[str], repo_url: Optional[str]) -> Optional[dict]:
    """Resolve a repo URL from either a direct URL or a search keyword.

    Returns a dict with 'url' and 'id' keys, or None if not found / user needs to choose.
    When multiple repos match, prints them as JSON for Claude to present to the user.
    """
    if repo_url:
        return {"url": repo_url, "id": None}

    if not search:
        print(json.dumps({"error": "Either --repo-search or --repo-url is required"}, ensure_ascii=False))
        return None

    result = manager.search_repos(search)
    success = result.get('success') or str(result.get('code')) == '200'
    if not success:
        print(json.dumps({"error": result.get('message', 'Search failed')}, ensure_ascii=False))
        return None

    data = result.get('data')
    repos = []
    if isinstance(data, dict):
        repo_vo_page = data.get('repoVOPage', {})
        if isinstance(repo_vo_page, dict) and 'data' in repo_vo_page:
            repos = repo_vo_page.get('data', [])
        else:
            repos = data.get('data', [])
    elif isinstance(data, list):
        repos = data

    if not repos:
        print(json.dumps({"error": f"No repositories found for keyword '{search}'"}, ensure_ascii=False))
        return None

    if len(repos) == 1:
        return {
            "url": repos[0].get('httpUrl'),
            "id": repos[0].get('id')
        }

    # Multiple matches: output list for Claude to present
    repo_list = []
    for idx, r in enumerate(repos, 1):
        repo_list.append({
            "index": idx,
            "id": r.get('id'),
            "name": r.get('name'),
            "path": r.get('path'),
            "httpUrl": r.get('httpUrl'),
            "description": r.get('description', ''),
        })
    print(json.dumps({
        "multiple_repos": repo_list,
        "message": f"Found {len(repo_list)} repositories. Please select one by providing --repo-url with the httpUrl value.",
    }, ensure_ascii=False, indent=2))
    return None


# ---- subcommands ----

def cmd_create(args):
    manager = GiteePRManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    if not args.source_branch:
        print(json.dumps({"error": "--source-branch is required"}, ensure_ascii=False))
        sys.exit(1)

    if not args.target_branch:
        print(json.dumps({"error": "--target-branch is required"}, ensure_ascii=False))
        sys.exit(1)

    if not args.title:
        print(json.dumps({"error": "--title is required"}, ensure_ascii=False))
        sys.exit(1)

    result = manager.create_pr(
        repo_url=repo_info['url'],
        source_branch=args.source_branch,
        target_branch=args.target_branch,
        title=args.title,
        description=args.description or "",
        user=args.user or "",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_close(args):
    manager = GiteePRManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    if not args.merge_request_iid:
        print(json.dumps({"error": "--merge-request-iid is required"}, ensure_ascii=False))
        sys.exit(1)

    result = manager.close_pr(
        repo_url=repo_info['url'],
        merge_request_iid=args.merge_request_iid,
        user=args.user or "",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_list(args):
    manager = GiteePRManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    result = manager.list_prs(
        repo_url=repo_info['url'],
        state=args.state or "",
        source_branch=args.source_branch or "",
        target_branch=args.target_branch or "",
        search=args.search or "",
        order_by=args.order_by or "",
        sort=args.sort or "",
        page=args.page,
        page_size=args.page_size,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_detail(args):
    manager = GiteePRManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    if not args.merge_request_iid:
        print(json.dumps({"error": "--merge-request-iid is required"}, ensure_ascii=False))
        sys.exit(1)

    result = manager.get_pr_detail(
        repo_url=repo_info['url'],
        merge_request_iid=args.merge_request_iid,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_accept(args):
    manager = GiteePRManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    if not args.merge_request_iid:
        print(json.dumps({"error": "--merge-request-iid is required"}, ensure_ascii=False))
        sys.exit(1)

    result = manager.accept_pr(
        repo_url=repo_info['url'],
        merge_request_iid=args.merge_request_iid,
        merge_commit_message=args.merge_commit_message or "",
        squash_commit_message=args.squash_commit_message or "",
        squash=args.squash,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_update(args):
    manager = GiteePRManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    if not args.merge_request_iid:
        print(json.dumps({"error": "--merge-request-iid is required"}, ensure_ascii=False))
        sys.exit(1)

    if not args.state_event:
        print(json.dumps({"error": "--state-event is required (closed/opened)"}, ensure_ascii=False))
        sys.exit(1)

    result = manager.update_pr(
        repo_url=repo_info['url'],
        merge_request_iid=args.merge_request_iid,
        state_event=args.state_event,
        title=args.title or "",
        description=args.description or "",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


# ---- main ----

def main():
    parser = argparse.ArgumentParser(
        description='Manage Gitee repository Pull Requests',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create a PR from feature branch to master
  python %(prog)s create --repo-search "my-project" --source-branch "feature/my-feature" --target-branch "master" --title "Add new feature"

  # List PRs
  python %(prog)s list --repo-search "my-project"

  # Get PR detail
  python %(prog)s detail --repo-search "my-project" --merge-request-iid 123

  # Accept/merge a PR
  python %(prog)s accept --repo-search "my-project" --merge-request-iid 123

  # Update PR (close/reopen)
  python %(prog)s update --repo-search "my-project" --merge-request-iid 123 --state-event closed
        """,
    )

    subparsers = parser.add_subparsers(dest='command', help='Operation to perform')
    subparsers.required = True

    # create subcommand
    sp_create = subparsers.add_parser('create', help='Create a Pull Request')
    repo_group = sp_create.add_mutually_exclusive_group(required=True)
    repo_group.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_create.add_argument('--source-branch', required=True, help='Source branch (the branch to merge from)')
    sp_create.add_argument('--target-branch', required=True, help='Target branch (the branch to merge into)')
    sp_create.add_argument('--title', required=True, help='Title of the Pull Request')
    sp_create.add_argument('--description', default='', help='Description of the Pull Request')
    sp_create.add_argument('--user', default='', help='User who creates the PR')

    # close subcommand (legacy, use update --state-event closed instead)
    sp_close = subparsers.add_parser('close', help='Close a Pull Request')
    repo_group2 = sp_close.add_mutually_exclusive_group(required=True)
    repo_group2.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group2.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_close.add_argument('--merge-request-iid', required=True, type=int, help='The IID (internal ID) of the Merge Request to close')
    sp_close.add_argument('--user', default='', help='User who closes the PR')

    # list subcommand
    sp_list = subparsers.add_parser('list', help='List Pull Requests')
    repo_group3 = sp_list.add_mutually_exclusive_group(required=True)
    repo_group3.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group3.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_list.add_argument('--state', default='', help='Filter by state: opened/closed/merged/all')
    sp_list.add_argument('--source-branch', default='', help='Filter by source branch')
    sp_list.add_argument('--target-branch', default='', help='Filter by target branch')
    sp_list.add_argument('--search', default='', help='Search keyword')
    sp_list.add_argument('--order-by', default='', help='Sort field: created_at/updated_at')
    sp_list.add_argument('--sort', default='', help='Sort order: asc/desc')
    sp_list.add_argument('--page', type=int, default=1, help='Page number (default: 1)')
    sp_list.add_argument('--page-size', type=int, default=20, help='Page size (default: 20)')

    # detail subcommand
    sp_detail = subparsers.add_parser('detail', help='Get Pull Request detail')
    repo_group4 = sp_detail.add_mutually_exclusive_group(required=True)
    repo_group4.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group4.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_detail.add_argument('--merge-request-iid', required=True, type=int, help='The IID of the Merge Request')

    # accept subcommand
    sp_accept = subparsers.add_parser('accept', help='Accept/Merge a Pull Request')
    repo_group5 = sp_accept.add_mutually_exclusive_group(required=True)
    repo_group5.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group5.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_accept.add_argument('--merge-request-iid', required=True, type=int, help='The IID of the Merge Request to accept')
    sp_accept.add_argument('--merge-commit-message', default='', help='Custom merge commit message')
    sp_accept.add_argument('--squash-commit-message', default='', help='Custom squash commit message')
    sp_accept.add_argument('--squash', action='store_true', help='Use squash merge')

    # update subcommand
    sp_update = subparsers.add_parser('update', help='Update a Pull Request')
    repo_group6 = sp_update.add_mutually_exclusive_group(required=True)
    repo_group6.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group6.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_update.add_argument('--merge-request-iid', required=True, type=int, help='The IID of the Merge Request to update')
    sp_update.add_argument('--state-event', required=True, help='State event: closed/opened')
    sp_update.add_argument('--title', default='', help='New title')
    sp_update.add_argument('--description', default='', help='New description')


    args = parser.parse_args()

    try:
        if args.command == 'create':
            cmd_create(args)
        elif args.command == 'close':
            cmd_close(args)
        elif args.command == 'list':
            cmd_list(args)
        elif args.command == 'detail':
            cmd_detail(args)
        elif args.command == 'accept':
            cmd_accept(args)
        elif args.command == 'update':
            cmd_update(args)
    except requests.exceptions.RequestException as e:
        print(json.dumps({"error": f"HTTP request failed: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"Network request failed: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(json.dumps({"error": f"Configuration error: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"error": f"Unexpected error: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        print(f"Unexpected error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
