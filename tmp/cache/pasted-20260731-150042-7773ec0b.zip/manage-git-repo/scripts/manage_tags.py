#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Manage Tags Script for Gitee Management

Supports three operations via subcommands:
  - list:   List tags of a repository (supports pagination and search filter)
  - create: Create a new tag from a branch or commit
  - delete: Delete an existing tag

Users provide a repo name (or search keyword). The script resolves the repo URL
automatically via the getRepoList API.
"""

import os
import sys
import json
import argparse
import requests
from typing import Optional, Dict, Any
from config_loader import ConfigLoader

_shared_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "shared"))
if _shared_dir not in sys.path:
    sys.path.insert(0, _shared_dir)

os.environ.setdefault("DEV_ASSISTANT_PROVIDER", "portal")
from _skill_auth_helper import get_token, infer_oauth_env

# 修复 Windows 环境下的编码问题（GBK 默认编码会导致 emoji/中文 UnicodeEncodeError）
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")


class GiteeTagManager:
    """Client for managing Gitee tags through the DevOps BFF layer"""

    def __init__(self):
        self.config_loader = ConfigLoader()
        self.config = self.config_loader.load_config()

    def _headers(self) -> Dict[str, str]:
        token = get_token(env=infer_oauth_env())
        return {
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': f'Bearer {token}'
        }

    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.config['bff_url']}/openapi/ai-code{path}"
        resp = requests.post(url, json=payload, headers=self._headers(), timeout=30, verify=False)
        resp.raise_for_status()
        return resp.json()

    def search_repos(self, keyword: str, page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        """Search repositories by keyword, returns the raw API response."""
        return self._post("/repo/getRepoList", {
            "repoType": "GITEE",
            "search": keyword,
            "hasStat": 0,
            "currentPage": page,
            "pageSize": page_size,
        })

    def list_tags(self, repo_url: str, search: str = "", page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        payload = {
            "repoType": "GITEE",
            "repoUrl": repo_url,
            "currentPage": page,
            "pageSize": page_size,
        }
        if search:
            payload["search"] = search
        return self._post("/repo/getRepoTagList", payload)

    def create_tag(self, repo_url: str, tag_name: str, ref: str, message: str = "") -> Dict[str, Any]:
        payload = {
            "repoType": "GITEE",
            "repoUrl": repo_url,
            "tagName": tag_name,
            "ref": ref,
        }
        if message:
            payload["message"] = message
        return self._post("/repo/createTag", payload)

    def delete_tag(self, repo_url: str, tag_name: str) -> Dict[str, Any]:
        return self._post("/repo/deleteTag", {
            "repoType": "GITEE",
            "repoUrl": repo_url,
            "tagName": tag_name,
        })


# ---- helpers ----

def resolve_repo_info(manager: GiteeTagManager, search: Optional[str], repo_url: Optional[str]) -> Optional[dict]:
    """Resolve a repo URL from either a direct URL or a search keyword.

    Returns a dict with 'url' and 'id' keys, or None if not found / user needs to choose.
    When multiple repos match, prints them as JSON for Claude to present to the user.
    """
    if repo_url:
        return {"url": repo_url, "id": None}

    if not search:
        print(json.dumps({"error": "Either --repo-search or --repo-url is required"}, ensure_ascii=False))
        return None

    result = manager.search_repos(search)
    success = result.get('success') or str(result.get('code')) == '200'
    if not success:
        print(json.dumps({"error": result.get('message', 'Search failed')}, ensure_ascii=False))
        return None

    data = result.get('data')
    repos = []
    if isinstance(data, dict):
        repo_vo_page = data.get('repoVOPage', {})
        if isinstance(repo_vo_page, dict) and 'data' in repo_vo_page:
            repos = repo_vo_page.get('data', [])
        else:
            repos = data.get('data', [])
    elif isinstance(data, list):
        repos = data

    if not repos:
        print(json.dumps({"error": f"No repositories found for keyword '{search}'"}, ensure_ascii=False))
        return None

    if len(repos) == 1:
        return {
            "url": repos[0].get('httpUrl'),
            "id": repos[0].get('id')
        }

    # Multiple matches: output list for Claude to present
    repo_list = []
    for idx, r in enumerate(repos, 1):
        repo_list.append({
            "index": idx,
            "id": r.get('id'),
            "name": r.get('name'),
            "path": r.get('path'),
            "httpUrl": r.get('httpUrl'),
            "description": r.get('description', ''),
        })
    print(json.dumps({
        "multiple_repos": repo_list,
        "message": f"Found {len(repo_list)} repositories. Please select one by providing --repo-url with the httpUrl value.",
    }, ensure_ascii=False, indent=2))
    return None


# ---- subcommands ----

def cmd_list(args):
    manager = GiteeTagManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    result = manager.list_tags(
        repo_url=repo_info['url'],
        search=args.search or "",
        page=args.page,
        page_size=args.page_size,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_create(args):
    manager = GiteeTagManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    result = manager.create_tag(
        repo_url=repo_info['url'],
        tag_name=args.tag_name,
        ref=args.ref,
        message=args.message or "",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def cmd_delete(args):
    manager = GiteeTagManager()
    repo_info = resolve_repo_info(manager, args.repo_search, args.repo_url)
    if not repo_info:
        sys.exit(1)

    result = manager.delete_tag(
        repo_url=repo_info['url'],
        tag_name=args.tag_name,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


# ---- main ----

def main():
    parser = argparse.ArgumentParser(
        description='Manage Gitee repository tags',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # List tags of a repository (search by keyword)
  python %(prog)s list --repo-search "my-project"

  # List tags (direct repo URL)
  python %(prog)s list --repo-url "https://gitee.com/org/my-project"

  # List tags with name filter and pagination
  python %(prog)s list --repo-search "my-project" --search "v1" --page 1 --page-size 10

  # Create a tag from master
  python %(prog)s create --repo-search "my-project" --tag-name "v1.0.0" --ref "master"

  # Create a tag with message
  python %(prog)s create --repo-search "my-project" --tag-name "v1.0.0" --ref "master" --message "Release version 1.0.0"

  # Delete a tag
  python %(prog)s delete --repo-search "my-project" --tag-name "v1.0.0-beta"

  # Delete with direct repo URL
  python %(prog)s delete --repo-url "https://gitee.com/org/my-project.git" --tag-name "v1.0.0-beta"
        """,
    )

    subparsers = parser.add_subparsers(dest='command', help='Operation to perform')
    subparsers.required = True

    # list subcommand
    sp_list = subparsers.add_parser('list', help='List tags of a repository')
    repo_group = sp_list.add_mutually_exclusive_group(required=True)
    repo_group.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_list.add_argument('--search', help='Fuzzy filter on tag name')
    sp_list.add_argument('--page', type=int, default=1, help='Page number (default: 1)')
    sp_list.add_argument('--page-size', type=int, default=20, help='Page size (default: 20)')

    # create subcommand
    sp_create = subparsers.add_parser('create', help='Create a new tag')
    repo_group2 = sp_create.add_mutually_exclusive_group(required=True)
    repo_group2.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group2.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_create.add_argument('--tag-name', required=True, help='Name of the new tag to create')
    sp_create.add_argument('--ref', required=True, help='Branch name or commit SHA to create the tag from')
    sp_create.add_argument('--message', help='Tag message/description')

    # delete subcommand
    sp_delete = subparsers.add_parser('delete', help='Delete a tag')
    repo_group3 = sp_delete.add_mutually_exclusive_group(required=True)
    repo_group3.add_argument('--repo-search', help='Search keyword to find the repository')
    repo_group3.add_argument('--repo-url', help='Direct repository URL (skips search)')
    sp_delete.add_argument('--tag-name', required=True, help='Name of the tag to delete')

    args = parser.parse_args()

    try:
        if args.command == 'list':
            cmd_list(args)
        elif args.command == 'create':
            cmd_create(args)
        elif args.command == 'delete':
            cmd_delete(args)
    except requests.exceptions.RequestException as e:
        print(json.dumps({"error": f"HTTP request failed: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(json.dumps({"error": f"Configuration error: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"error": f"Unexpected error: {str(e)}"}, ensure_ascii=False), file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
