#!/usr/bin/env python3
"""
Configuration loader for Gitee Management scripts

This module provides shared functionality for loading configuration from config file.
With unified authentication SDK integration, domain_account is no longer needed.
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any

# 根据 CK_ENV / PLATFORM_ENV 环境变量解析基础域名，默认生产环境
def _resolve_base_domain() -> str:
    env = (os.getenv("CK_ENV") or os.getenv("PLATFORM_ENV") or "").strip().lower()
    if env == "dev":
        return "https://one-dev.iflytek.com"
    if env in ("test", "pre"):
        return "https://one-test.iflytek.com"
    return "https://one.iflytek.com"


# 生产环境默认值
DEFAULT_BFF_URL = f"{_resolve_base_domain()}/devops/api/ai-bff"


class ConfigLoader:
    """Load and manage configuration for Gitee management scripts"""

    def __init__(self, config_path: Optional[Path] = None):
        """Initialize configuration loader

        Args:
            config_path: Optional path to configuration file (currently unused, kept for compatibility)
        """
        self.config_path = config_path or (Path.home() / '.devops' / 'credentials.json')
        self._config_cache: Optional[Dict[str, str]] = None

    def load_config(self) -> Dict[str, str]:
        """Load configuration from default values

        Returns:
            Dictionary with bff_url

        Note:
            domain_account is no longer needed as authentication is handled by skill_auth SDK
        """
        if self._config_cache:
            return self._config_cache

        # Use default BFF URL directly
        bff_url = DEFAULT_BFF_URL

        config = {
            'bff_url': bff_url,
        }

        self._config_cache = config
        return config

    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Get a specific configuration value

        Args:
            key: Configuration key
            default: Default value if key not found

        Returns:
            Configuration value or default
        """
        config = self.load_config()
        return config.get(key, default)


# Convenience function for quick access
def get_config(config_path: Optional[Path] = None) -> Dict[str, str]:
    """Get configuration dictionary

    Args:
        config_path: Optional path to configuration file

    Returns:
        Configuration dictionary
    """
    loader = ConfigLoader(config_path)
    return loader.load_config()
