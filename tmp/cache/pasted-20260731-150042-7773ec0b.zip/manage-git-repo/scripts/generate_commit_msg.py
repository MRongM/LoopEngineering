#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate Commit Message Script for Gitee Management

Analyzes git diff output and generates commit messages following project convention:
  类型(范围): T-xxx 任务简述

Types: feat, fix, refactor, docs, chore
Scope: Agent directory name (kebab-case)
Task ID: T-xxx format, from --task-id or branch name
"""

import os
import sys
import json
import argparse
import re
from typing import Dict, Any, Optional, List, Tuple

# 修复 Windows 环境下的编码问题（GBK 默认编码会导致 emoji/中文 UnicodeEncodeError）
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")


class CommitMessageGenerator:
    """Generate commit messages by analyzing git diff output"""

    # Change type detection patterns
    TYPE_PATTERNS = {
        'feat': [
            r'^\+.*def\s+\w+\(',  # New function
            r'^\+.*class\s+\w+',  # New class
            r'^\+.*@app\.route',  # New API endpoint
            r'^\+.*export\s+(function|const|class)',  # New JS/TS export
            r'^\+.*public\s+(class|interface|enum)',  # New Java public type
        ],
        'fix': [
            r'\b(fix|bug|issue|error|crash|problem)\b',  # Bug keywords
            r'test.*\.py$',  # Test file changes
            r'test.*\.js$',
            r'.*_test\.go$',
        ],
        'docs': [
            r'\.md$',  # Markdown files
            r'\.txt$',
            r'\.rst$',
            r'README',
            r'CHANGELOG',
        ],
        'chore': [
            r'package\.json$',  # Dependencies
            r'requirements\.txt$',
            r'go\.mod$',
            r'pom\.xml$',
            r'\.gitignore$',  # Config files
            r'\.env\.example$',
            r'Dockerfile$',
            r'docker-compose',
        ],
    }

    # Refactor indicators
    REFACTOR_INDICATORS = [
        'rename',
        'move',
        'refactor',
        'restructure',
        'reorganize',
    ]

    def __init__(self):
        pass

    def parse_diff(self, diff_content: str) -> Dict[str, Any]:
        """Parse git diff output and extract file changes"""
        if not diff_content or not diff_content.strip():
            return {
                'files': [],
                'additions': 0,
                'deletions': 0,
                'new_files': [],
                'modified_files': [],
                'deleted_files': [],
            }

        files = []
        new_files = []
        modified_files = []
        deleted_files = []
        additions = 0
        deletions = 0

        current_file = None
        for line in diff_content.split('\n'):
            # File header: diff --git a/path b/path
            if line.startswith('diff --git'):
                match = re.search(r'b/(.+)$', line)
                if match:
                    current_file = match.group(1)
                    files.append(current_file)

            # New file
            elif line.startswith('new file mode'):
                if current_file:
                    new_files.append(current_file)

            # Deleted file
            elif line.startswith('deleted file mode'):
                if current_file:
                    deleted_files.append(current_file)

            # Modified file (has @@ hunk header)
            elif line.startswith('@@') and current_file:
                if current_file not in new_files and current_file not in deleted_files:
                    if current_file not in modified_files:
                        modified_files.append(current_file)

            # Count additions/deletions
            elif line.startswith('+') and not line.startswith('+++'):
                additions += 1
            elif line.startswith('-') and not line.startswith('---'):
                deletions += 1

        return {
            'files': files,
            'additions': additions,
            'deletions': deletions,
            'new_files': new_files,
            'modified_files': modified_files,
            'deleted_files': deleted_files,
        }

    def detect_change_type(self, diff_content: str, diff_info: Dict[str, Any]) -> Tuple[str, str]:
        """Detect change type based on diff content and file patterns

        Returns:
            (type, reason) tuple
        """
        files = diff_info['files']
        new_files = diff_info['new_files']

        # Check for docs-only changes
        if files and all(self._matches_patterns(f, self.TYPE_PATTERNS['docs']) for f in files):
            return 'docs', '所有变更文件均为文档文件'

        # Check for chore patterns (config/dependency files)
        if files and all(self._matches_patterns(f, self.TYPE_PATTERNS['chore']) for f in files):
            return 'chore', '变更文件为配置或依赖文件'

        # Check for refactor indicators
        for indicator in self.REFACTOR_INDICATORS:
            if indicator in diff_content.lower():
                return 'refactor', f'检测到重构关键词: {indicator}'

        # Check for fix patterns
        if self._matches_patterns(diff_content, self.TYPE_PATTERNS['fix']):
            return 'fix', '检测到 bug 修复相关关键词或测试文件变更'

        # Check for feat patterns (new code)
        if new_files or self._matches_patterns(diff_content, self.TYPE_PATTERNS['feat']):
            if new_files:
                return 'feat', f'新增文件: {", ".join(new_files[:3])}'
            else:
                return 'feat', '检测到新增函数、类或 API 端点'

        # Default to feat if there are additions
        if diff_info['additions'] > diff_info['deletions']:
            return 'feat', '新增代码行数多于删除行数'

        # Default to refactor
        return 'refactor', '代码变更未匹配到明确类型'

    def _matches_patterns(self, text: str, patterns: List[str]) -> bool:
        """Check if text matches any of the regex patterns"""
        for pattern in patterns:
            if re.search(pattern, text, re.IGNORECASE | re.MULTILINE):
                return True
        return False

    def extract_scope(self, files: List[str]) -> Tuple[Optional[str], str]:
        """Extract scope from file paths

        Returns:
            (scope, reason) tuple
        """
        if not files:
            return None, '无文件变更'

        # Extract directory prefixes
        dirs = []
        for f in files:
            parts = f.split('/')
            if len(parts) > 1:
                # Get first directory
                dirs.append(parts[0])

        if not dirs:
            return None, '文件均在根目录'

        # Find most common directory
        from collections import Counter
        dir_counts = Counter(dirs)
        most_common_dir, count = dir_counts.most_common(1)[0]

        # Check if it's an agent directory (ends with -assistant or is 'pa')
        if most_common_dir.endswith('-assistant') or most_common_dir == 'pa':
            return most_common_dir, f'变更文件主要位于 {most_common_dir}/ 目录'

        # Check if it's a known directory
        known_dirs = ['.claude', 'specs', 'tool', 'dev-assistant', 'pa',
                      'product-assistant', 'efficiency-assistant', 'oa-assistant',
                      'yunfan-assistant']
        if most_common_dir in known_dirs:
            return most_common_dir, f'变更文件位于 {most_common_dir}/ 目录'

        # Use the most common directory
        return most_common_dir, f'变更文件主要位于 {most_common_dir}/ 目录'

    def extract_task_id(self, task_id_arg: Optional[str], branch_name: Optional[str]) -> Tuple[Optional[str], str]:
        """Extract task ID from argument or branch name

        Returns:
            (task_id, reason) tuple
        """
        # Priority 1: --task-id argument
        if task_id_arg:
            # Validate format
            if re.match(r'^T-\d+$', task_id_arg):
                return task_id_arg, f'从 --task-id 参数获取: {task_id_arg}'
            else:
                return None, f'--task-id 格式错误: {task_id_arg}，应为 T-xxx 格式'

        # Priority 2: Extract from branch name
        if branch_name:
            match = re.search(r'T-\d+', branch_name)
            if match:
                task_id = match.group(0)
                return task_id, f'从分支名提取: {branch_name} → {task_id}'

        return None, '未提供任务编号，请使用 --task-id 参数指定'

    def generate_description(self, change_type: str, diff_info: Dict[str, Any]) -> str:
        """Generate a brief description based on change type and diff info"""
        new_files = diff_info['new_files']
        modified_files = diff_info['modified_files']
        deleted_files = diff_info['deleted_files']

        if change_type == 'feat':
            if new_files:
                return f'新增功能'
            return '新增功能'
        elif change_type == 'fix':
            return '修复问题'
        elif change_type == 'refactor':
            return '重构代码'
        elif change_type == 'docs':
            return '更新文档'
        elif change_type == 'chore':
            return '更新配置'

        return '代码变更'

    def generate(self, diff_content: str, task_id_arg: Optional[str] = None,
                 branch_name: Optional[str] = None) -> Dict[str, Any]:
        """Generate commit message from git diff output

        Args:
            diff_content: Output from 'git diff --staged'
            task_id_arg: Task ID from --task-id argument
            branch_name: Current branch name for task ID extraction

        Returns:
            Dictionary with commit message and metadata
        """
        # Parse diff
        diff_info = self.parse_diff(diff_content)

        if not diff_info['files']:
            return {
                'error': '没有检测到文件变更，请先使用 git add 暂存文件',
                'commit_message': None,
                'confidence': 0.0,
            }

        # Detect change type
        change_type, type_reason = self.detect_change_type(diff_content, diff_info)

        # Extract scope
        scope, scope_reason = self.extract_scope(diff_info['files'])

        # Extract task ID
        task_id, task_reason = self.extract_task_id(task_id_arg, branch_name)

        # Generate description
        description = self.generate_description(change_type, diff_info)

        # Calculate confidence
        confidence = 0.9
        if not task_id:
            confidence = 0.5  # Low confidence without task ID
        elif not scope:
            confidence = 0.7  # Medium confidence without clear scope

        # Build commit message
        if scope:
            commit_message = f"{change_type}({scope}): {task_id} {description}" if task_id else f"{change_type}({scope}): {description}"
        else:
            commit_message = f"{change_type}: {task_id} {description}" if task_id else f"{change_type}: {description}"

        return {
            'commit_message': commit_message,
            'type': change_type,
            'scope': scope,
            'task_id': task_id,
            'description': description,
            'confidence': confidence,
            'type_reason': type_reason,
            'scope_reason': scope_reason,
            'task_reason': task_reason,
            'diff_summary': {
                'files_changed': len(diff_info['files']),
                'additions': diff_info['additions'],
                'deletions': diff_info['deletions'],
                'new_files': len(diff_info['new_files']),
                'modified_files': len(diff_info['modified_files']),
                'deleted_files': len(diff_info['deleted_files']),
            }
        }


def main():
    parser = argparse.ArgumentParser(
        description='Generate commit message from git diff output',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate from staged changes with task ID
  git diff --staged | python generate_commit_msg.py --task-id T-123

  # Generate with branch name (extracts task ID from branch)
  git diff --staged | python generate_commit_msg.py --branch-name feature/T-123-add-login

  # Generate without task ID (lower confidence)
  git diff --staged | python generate_commit_msg.py
        """
    )

    parser.add_argument('--task-id', help='Task ID in T-xxx format')
    parser.add_argument('--branch-name', help='Current branch name (for task ID extraction)')
    parser.add_argument('--diff-file', help='Read diff from file instead of stdin')

    args = parser.parse_args()

    try:
        # Read diff content
        if args.diff_file:
            with open(args.diff_file, 'r', encoding='utf-8') as f:
                diff_content = f.read()
        else:
            diff_content = sys.stdin.read()

        # Generate commit message
        generator = CommitMessageGenerator()
        result = generator.generate(diff_content, args.task_id, args.branch_name)

        # Output JSON
        print(json.dumps(result, ensure_ascii=False, indent=2))

        # Exit with error code if no commit message generated
        if not result.get('commit_message'):
            sys.exit(1)

    except Exception as e:
        error_result = {
            'error': f'生成 commit message 失败: {str(e)}',
            'commit_message': None,
            'confidence': 0.0,
        }
        print(json.dumps(error_result, ensure_ascii=False, indent=2), file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
