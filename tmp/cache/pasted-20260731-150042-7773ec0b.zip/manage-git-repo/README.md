# Gitee Management Skill

A Claude Code skill for managing Gitee repositories through the DevOps BFF layer.

## Features

- **Create Repository**: Create new Gitee repositories with custom configuration
- **Add Members**: Add team members to repositories with role-based permissions
- **List Repositories**: Query and browse repositories with filtering and sorting

## Installation

1. Copy this skill directory to your Claude skills folder:
   ```bash
   cp -r manage-git-repo ~/.claude/skills/
   ```

2. Authentication is handled automatically by the skill_auth SDK using OAuth 2.1 + PKCE.
   - First use will prompt for OAuth authorization via browser
   - Token is stored locally in `~/.skill-auth/tokens/skill-b.json`
   - Token refreshes automatically when expired


## Usage

### Create a Repository

```bash
python scripts/create_repo.py --name "my-project" --description "My awesome project"
```

### Add Members

```bash
python scripts/add_member.py --repo-id 12345 --members "john@company.com:developer,jane@company.com:maintainer"
```

### List Repositories

```bash
python scripts/list_repos.py --search "frontend" --visibility private
```

## Documentation

- `SKILL.md` - Main skill documentation
- `references/create_repo.md` - Create repository API reference
- `references/add_member.md` - Add member API reference
- `references/list_repos.md` - List repositories API reference

## Security

- Never hardcode credentials in scripts
- Authentication handled by skill_auth SDK (OAuth 2.1 + PKCE)
- Token automatically obtained, stored, and refreshed
- Complete audit logging for all operations
- Token stored locally with secure permissions

## License

Internal DevOps Platform Tool
