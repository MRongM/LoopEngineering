# 创建仓库 - API 参考

## 概述

在 Gitee 中使用指定配置创建新仓库。

## 重要事项

此 Skill 涉及 2 个 API，都在 create_repo.py 中：
1. `create_repository(name, path, namespace_id)` - 创建仓库
2. `list_groups(search, page, per_page)` - 查询组织列表

**调用方式**：直接运行 `python create_repo.py`，脚本会自动设置 PYTHONPATH，无需手动设置。

### 查询组织列表接口

```
POST /ai-code/codeWarehouse/pageGroupsBySearch
```

### 请求头

```
Content-Type: application/json; charset=UTF-8
```


### 请求体

```json
{
  "repoType": "GITEE",
  "currentPage": 1,
  "pageSize": 10,
  "search": ""
}
```

### 响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "groupVOPage": {
      "total": 806,
      "totalPages": 162,
      "currentPage": 1,
      "pageSize": 5,
      "data": [
        {
          "feignType": "giteeGroupListVO",
          "id": "2",
          "name": "g1",
          "path": "g1",
          "description": "",
          "fullName": "",
          "fullPath": "",
          "visibility": "private",
          "avatarUrl": "",
          "webUrl": "https://codetest.iflytek.com/osc/_source/groups//-/index",
          "parentId": "0",
          "createdAt": "2022-09-15T14:18:19.758+08:00",
          "childExists": false
        }
      ]
    },
    "repoType": "GITEE"
  },
  "traceId": ""
}
```

---

## 创建仓库接口

```
POST /ai-code/codeWarehouse/createRepo
```

## 请求头

```
Content-Type: application/json; charset=UTF-8
```



## 请求体

```json
{
  "repoType": "GITEE",
  "name": "string (必填)",
  "path": "string (可选)",
  "namespaceId": 0
}
```

### 参数

| 参数 | 类型 | 必填 | 说明 |
|-----------|------|----------|----------------|
| repoType | string | 是 | 仓库类型，必须为 "GITEE" |
| name | string | 是 | 仓库名称（2-100 个字符），支持中文 |
| path | string | 否 | 仓库路径（URL 标识）。未提供时从名称自动生成 |
| namespaceId | long | 否 | 命名空间/组织 ID（0 或 null 表示个人空间） |

## 响应

### 成功响应 (200 OK)

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 474294,
    "name": "api-response-test-repo-2",
    "path": "api-response-test-repo-2",
    "description": "",
    "webUrl": "https://codetest.iflytek.com/bofeng/api-response-test-repo-2",
    "sshUrl": null,
    "httpUrl": null,
    "namespaceId": null,
    "createdAt": "2026-04-08T11:21:24.058850725+08:00"
  },
  "traceId": ""
}
```

### 错误响应

```json
{
  "code": 500,
  "message": "创建Gitee仓库失败: ...",
  "data": null
}
```

## 错误码

| 错误码 | 说明 |
|------|----------------|
| 500 | 创建仓库失败，可能原因：仓库名重复、网络错误、权限不足等 |

## 示例

### 示例 1：在个人空间创建仓库

**请求**：
```json
{
  "repoType": "GITEE",
  "name": "my-project"
}
```

**响应**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": 12345,
    "name": "my-project",
    "path": "my-project",
    "description": null,
    "webUrl": "https://gitee.com/yyzhu4/my-project",
    "sshUrl": "git@gitee.com:yyzhu4/my-project.git",
    "httpUrl": "https://gitee.com/yyzhu4/my-project.git",
    "namespaceId": 0,
    "createdAt": "2026-03-10T10:30:00Z"
  }
}
```

### 示例 2：创建中文名称的仓库

当仓库名称包含中文字符时，应提供对应的英文 `path` 参数用于 URL。

**请求**：
```json
{
  "repoType": "GITEE",
  "name": "从skill创建的仓库",
  "path": "create-repo-from-skill"
}
```

**响应**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": 12347,
    "name": "从skill创建的仓库",
    "path": "create-repo-from-skill",
    "description": null,
    "webUrl": "https://gitee.com/yyzhu4/create-repo-from-skill",
    "sshUrl": "git@gitee.com:yyzhu4/create-repo-from-skill.git",
    "httpUrl": "https://gitee.com/yyzhu4/create-repo-from-skill.git",
    "namespaceId": 0,
    "createdAt": "2026-03-10T10:32:00Z"
  }
}
```

### 示例 3：在组织下创建仓库

**请求**：
```json
{
  "repoType": "GITEE",
  "name": "team-project",
  "namespaceId": 12345
}
```

**响应**：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": 12346,
    "name": "team-project",
    "path": "team-project",
    "description": null,
    "webUrl": "https://gitee.com/my-org/team-project",
    "sshUrl": "git@gitee.com:my-org/team-project.git",
    "httpUrl": "https://gitee.com/my-org/team-project.git",
    "namespaceId": 12345,
    "createdAt": "2026-03-10T10:31:00Z"
  }
}
```

## 脚本用法

```bash
# 使用命令行参数（交互式选择命名空间）
python scripts/create_repo.py --name "my-project"

# 创建中文名称的仓库（需提供英文路径）
python scripts/create_repo.py --name "从skill创建的仓库" --path "create-repo-from-skill"

# 直接创建在个人空间
python scripts/create_repo.py --name "my-project" --namespace-id 0

# 创建在指定组织下
python scripts/create_repo.py --name "my-project" --namespace-id 12345
```

## 交互式工作流（通过 Claude 对话）

当未提供 namespace_id 时，按以下交互模式进行：

1. **询问用户**："你想将仓库创建在个人空间还是组织下？"
   - 如果选择个人空间 → 使用 `namespace_id=0`
   - 如果选择组织 → 进入步骤 2

2. **查询可用组织**（如果用户选择了组织）：
   - 使用 `list_groups()` 方法获取第一页（page=1, per_page=10）
   - 显示组织的 ID、名称和路径
   - 要求用户通过 ID 选择组织

3. **确认选择**并创建仓库

**中文名称注意事项**：当仓库名称包含中文字符时，必须提供英文 `--path` 参数作为仓库 URL 标识。路径只能包含小写字母、数字和连字符。

## 注意事项

- 仓库名称在命名空间内必须唯一
- 仓库名称支持中文字符
- `path` 参数用于仓库 URL（只能包含小写字母、数字和连字符）
- 如果未提供 `path`，将从 `name` 自动生成（小写，空格替换为连字符）
- 对于中文名称，请始终提供英文 `path` 参数以获得可用的 URL
- namespaceId=0 或 null 表示创建在个人空间
- 如果未提供 namespaceId，脚本将提示用户选择
- 响应中提供了 Git URL 和 SSH URL，可立即用于克隆

## 典型场景示例（用户对话）

### 示例 1 — 创建个人仓库

```
用户：创建一个 my-project 的仓库
AI：你想将仓库创建在个人空间还是组织下？

用户：个人空间
AI：正在创建仓库...

✅ 仓库创建成功！

• 仓库名称: my-project
• 仓库路径: my-project
• 访问地址: https://codetest.iflytek.com/zhangsan/my-project
• 仓库ID: 474294

[邀请成员]
```

### 示例 2 — 创建组织仓库

```
用户：新建代码仓库 team-service
AI：你想将仓库创建在个人空间还是组织下？

用户：组织
AI：正在查询可用组织...

┌──────┬────────────────┬────────────────┐
│ ID   │ 组织名称       │ 路径           │
├──────┼────────────────┼────────────────┤
│ 2    │ g1             │ g1             │
│ 6    │ jingyun-1-cs   │ jingyun-1      │
│ 7    │ jingyun-1-1    │ jingyun-1-1    │
└──────┴────────────────┴────────────────┘

请通过 ID 选择一个组织：

用户：6
AI：正在创建仓库到组织 jingyun-1-cs...

✅ 仓库创建成功！

• 仓库名称: team-service
• 仓库路径: team-service
• 访问地址: https://codetest.iflytek.com/jingyun-1/team-service
• 仓库ID: 474295

 [邀请成员]
```

### 示例 3 — 创建中文名称仓库

```
用户：创建一个叫"测试项目"的仓库
AI：仓库名称包含中文，需要提供一个英文路径作为 URL 标识。请输入英文路径（只能包含小写字母、数字和连字符）：

用户：test-project
AI：你想将仓库创建在个人空间还是组织下？

用户：个人空间
AI：正在创建仓库...

✅ 仓库创建成功！

• 仓库名称: 测试项目
• 仓库路径: test-project
• 访问地址: https://codetest.iflytek.com/zhangsan/test-project
• 仓库ID: 474296

[邀请成员]
```

### 输出字段说明

| 输出项 | 类型 | 说明 |
|--------|------|------|
| 仓库名称 | String | 仓库的显示名称 |
| 仓库路径 | String | 仓库的 URL 路径标识 |
| 访问地址 | String | 仓库的 Web 访问地址 |
| 仓库ID | Integer | 仓库数字 ID |
