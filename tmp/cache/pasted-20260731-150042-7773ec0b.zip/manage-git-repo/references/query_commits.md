# 查询提交记录 - API 参考

## 概述

查询 Gitee 仓库提交记录：列出提交和获取提交详情。所有操作都通过 BFF 层，实现在 `scripts/query_commits.py` 中。**不要**创建其他文件、使用 curl 或编写临时 Python 脚本。

## 重要事项

1. 所有提交 API 共用同一个脚本 `query_commits.py`，通过子命令（`list`、`detail`）区分。
2. 用户只需提供**仓库名称/搜索关键词**。脚本会自动解析仓库 URL。
3. 提交列表支持通过 `--page` 和 `--page-size` 分页，并提供分支、日期范围和提交者过滤。
4. 查询提交详情时，`--commit-id` 为必填，用于指定提交的 SHA 哈希值。

## 通用请求头

```
Content-Type: application/json; charset=UTF-8
Authorization: Bearer <access_token>
```


---

## 1. 列出提交记录

### 接口

```
POST /ai-code/repo/getRepoCommitList
```

### 请求体

```json
{
  "repoType": "gitee",
  "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "branch": "master",
  "search": "",
  "fromDate": "2026-03-01",
  "toDate": "2026-03-20",
  "userName": "",
  "currentPage": 1,
  "pageSize": 20
}
```

### 参数

- `repoType`（string，必填）：始终为 `"gitee"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `branch`（string，可选）：按分支名称过滤
- `search`（string，可选）：按提交消息模糊搜索的关键词
- `fromDate`（string，可选）：起始日期过滤（格式：YYYY-MM-DD）
- `toDate`（string，可选）：结束日期过滤（格式：YYYY-MM-DD）
- `userName`（string，可选）：按提交者用户名过滤
- `currentPage`（integer，可选）：页码，默认 1
- `pageSize`（integer，可选）：每页数量，默认 20

### 响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "commitVOPage": {
      "total": 50,
      "totalPages": 3,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "type": "giteeCommitVO",
          "commitId": "abc123def456789",
          "commitMessage": "feat: add new feature for user authentication",
          "committer": "zhangsan",
          "commitTime": "2026-03-15T10:30:00Z",
          "addition": 150,
          "deletion": 20
        },
        {
          "type": "giteeCommitVO",
          "commitId": "def456ghi789012",
          "commitMessage": "fix: resolve login bug",
          "committer": "lisi",
          "commitTime": "2026-03-14T08:20:00Z",
          "addition": 30,
          "deletion": 10
        }
      ]
    },
    "repoType": "gitee"
  },
  "traceId": ""
}
```

### 响应字段

- `commitId`：提交的 SHA 哈希值
- `commitMessage`：完整的提交消息
- `committer`：提交者的用户名
- `commitTime`：提交时间戳
- `addition`：此次提交新增的行数
- `deletion`：此次提交删除的行数

### 脚本用法

```bash
# 通过仓库搜索关键词列出提交
python scripts/query_commits.py list --repo-search "my-project"

# 使用直接仓库 URL 列出提交
python scripts/query_commits.py list --repo-url "https://gitee.com/org/my-project.git"

# 按分支过滤列出提交
python scripts/query_commits.py list --repo-search "my-project" --branch "develop"

# 按日期范围和分页列出提交
python scripts/query_commits.py list --repo-search "my-project" --from-date "2026-03-01" --to-date "2026-03-20" --page 1 --page-size 10

# 列出特定用户的提交
python scripts/query_commits.py list --repo-search "my-project" --user-name "zhangsan"
```

---

## 2. 查询提交详情

### 接口

```
POST /ai-code/codeWarehouse/queryCommitDetail
```

### 请求体

```json
{
  "repoType": "gitee",
  "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "commitId": "86d940d6a55d4d019dd10c819b0694d5d18dbc92"
}
```

### 参数

- `repoType`（string，必填）：始终为 `"gitee"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `commitId`（string，必填）：要查询的提交 SHA 哈希值

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "commitDetailVO": {
      "commitId": "abc123def456789",
      "commitTitle": "feat: add new feature for user authentication",
      "commitMessage": "feat: add new feature for user authentication\n\nThis commit adds OAuth2 support for user login.\nIncludes refresh token handling and session management.",
      "committer": "zhangsan",
      "committerEmail": "zhangsan@example.com",
      "commitTime": "2026-03-15T10:30:00Z",
      "additions": 150,
      "deletions": 20,
      "total": 170
    },
    "repoType": "gitee",
    "commitId": "abc123def456789",
    "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git"
  },
  "traceId": ""
}
```

### 响应字段

- `commitId`：提交的 SHA 哈希值
- `commitTitle`：提交消息的第一行（主题）
- `commitMessage`：包含正文的完整提交消息
- `committer`：提交者的用户名
- `committerEmail`：提交者的邮箱
- `commitTime`：提交时间戳
- `additions`：新增行数
- `deletions`：删除行数
- `total`：总变更行数（新增 + 删除）

### 脚本用法

```bash
# 通过仓库搜索关键词查询提交详情
python scripts/query_commits.py detail --repo-search "my-project" --commit-id "abc123def456789"

# 使用直接仓库 URL 查询提交详情
python scripts/query_commits.py detail --repo-url "https://gitee.com/org/my-project" --commit-id "abc123def456789"
```

---

## 处理多个仓库匹配

当 `--repo-search` 匹配到多个仓库时，脚本返回退出码 1 并附带 JSON 响应列出所有匹配项。这是预期行为。

```json
{
  "multiple_repos": [
    {
      "index": 1,
      "id": 474192,
      "name": "my-project-v2",
      "path": "my-project-v2",
      "httpUrl": "https://codetest.iflytek.com/my-project-v2.git",
      "description": ""
    },
    {
      "index": 2,
      "id": 474190,
      "name": "my-project",
      "path": "my-project",
      "httpUrl": "https://codetest.iflytek.com/my-project.git",
      "description": ""
    }
  ],
  "message": "Found 2 repositories. Please select one by providing --repo-url with the httpUrl value."
}
```

将列表展示给用户，请用户通过索引选择，然后使用对应的 `httpUrl` 作为 `--repo-url`。

---

## 错误响应

所有接口的错误响应格式如下：

```json
{
  "success": false,
  "code": "500",
  "message": "错误描述",
  "data": null,
  "traceId": ""
}
```

常见错误：
- 配置缺失或无效
- 仓库未找到
- 提交未找到（无效的 `--commit-id`）
- 分支未找到（无效的 `--branch`）
- 权限被拒绝
- 网络连接问题
