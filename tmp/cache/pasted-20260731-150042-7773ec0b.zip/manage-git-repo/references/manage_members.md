# 管理项目成员 - API 参考

## 概述

管理 Gitee 仓库成员：列出、添加、更新和删除。所有操作都通过 BFF 层，实现在 `scripts/manage_members.py` 中。**不要**创建其他文件或使用 curl。

## 重要事项

1. 所有成员 API 共用同一个脚本 `manage_members.py`，通过子命令（`list`、`add`、`update`、`delete`）区分。
2. 用户只需提供**成员域账号**和**仓库名称/搜索关键词**。脚本会自动解析仓库 URL。
3. 删除操作时，脚本会先列出成员自动查找对应的 `userId`。
4. **关键**：添加/更新成员**需要项目的数字 ID**（`projectId`）。该 ID 从仓库搜索结果中获取。
5. **`add` 用于添加新成员**：如果成员已存在会失败。
6. **`update` 用于添加或更新成员权限**：直接调用 addOrUpdateProjectMember，不检查成员是否已存在。

## 通用请求头

```
Content-Type: application/json; charset=UTF-8
```


## accessLevel 参考

| 角色名称          | accessLevel | 说明 |
|------------------|-------------|------|
| guest            | 2           | 访客  |
| collaborator     | 4           | 协作  |
| configurator     | 6           | 配置  |
| admin            | 8           | 管理员 |

---

## 1. 列出项目成员

### 接口

```
POST /ai-code/repo/getProjectMembers
```

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git"
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）

### 响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": [
    {
      "id": 388986,
      "username": "sschu2",
      "login": null,
      "name": "sschu2",
      "email": "sschu2@iflytek.com",
      "avatarUrl": null,
      "accessLevel": 8,
      "createdAt": "2026-03-18T16:56:35.31273+08:00"
    }
  ],
  "traceId": ""
}
```

### 脚本用法

```bash
# 通过关键词搜索仓库
python manage_members.py list --repo-search "my-project"

# 使用直接仓库 URL（使用仓库搜索结果中的 httpUrl）
python manage_members.py list --repo-url "https://gitee.com/org/my-project.git"
```

---

## 2. 搜索仓库（获取项目 ID）

### 为什么需要此操作

添加或更新项目成员时，后端 API **需要项目的数字 ID**（`projectId`）。该 ID 通过先搜索仓库来获取。

### 接口

```
POST /ai-code/repo/getRepoList
```

### 请求体

```json
{
  "repoType": "GITEE",
  "search": "my-project",
  "currentPage": 1,
  "pageSize": 20
}
```

### 响应

响应包含仓库列表，每个仓库有一个数字 `id` 字段：

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "repoVOPage": {
      "data": [
        {
          "id": 474190,
          "name": "0311测试仓库",
          "path": "0311-test-repo-v2",
          "webUrl": "https://codetest.iflytek.com/osc/_source/yyzhu4/0311-test-repo-v2/-/code/",
          "description": ""
        }
      ]
    }
  }
}
```

**重要**：`id` 字段（如 `474190`）是添加成员时必须使用的项目数字 ID。

### 脚本用法

```bash
# 通过关键词搜索仓库
python manage_members.py search --keyword "my-project"
```

### 多个仓库匹配

如果多个仓库匹配搜索关键词，脚本返回：

```json
{
  "multiple_repos": [
    {
      "index": 1,
      "id": 474192,
      "name": "0311测试仓库2",
      "path": "0311-test-repo-2",
      "httpUrl": "https://codetest.iflytek.com/0311-test-repo-2.git",
      "description": ""
    },
    {
      "index": 2,
      "id": 474190,
      "name": "0311测试仓库",
      "path": "0311-test-repo-v2",
      "httpUrl": "https://codetest.iflytek.com/0311-test-repo-v2.git",
      "description": ""
    }
  ],
  "message": "Found 2 repositories. Please select one by providing --repo-url with the httpUrl value."
}
```

此时，将列表展示给用户，请用户通过 `index` 选择，然后使用对应的 `httpUrl` 作为 `--repo-url`。

## ⚠️ 故障排除：处理多个仓库匹配

### 问题
使用 `--repo-search` 搜索关键词匹配到多个仓库时，脚本返回退出码 1 并附带 JSON 响应显示所有匹配的仓库。这是**预期行为**，不是错误。

### 为什么会这样
脚本的 `resolve_repo_info()` 函数设计为：
1. 0 个匹配时 → 返回**错误**
2. 恰好 1 个匹配时 → **自动选择**
3. 多个匹配时 → **展示选项**（需要用户选择）

### 示例场景
```bash
# 此搜索匹配了 20 个包含 "2131" 的仓库
python scripts/manage_members.py add --repo-search "2131" --member "zxke"

# 返回退出码 1 并附带 multiple_repos 列表
```

### 解决方案

#### 方案 1：使用更精确的搜索关键词
```bash
# 包含命名空间或完整路径以获得更好的匹配
python scripts/manage_members.py add --repo-search "bofeng/2131" --member "zxke"
```

#### 方案 2：使用直接 URL + 项目 ID（推荐）
```bash
# 最可靠 - 完全跳过搜索（使用仓库搜索结果中的 httpUrl）
python scripts/manage_members.py add \
  --repo-url "https://codetest.iflytek.com/bofeng/2131.git" \
  --project-id 474242 \
  --member "zxke"
```

#### 方案 3：交互式选择流程
```bash
# 步骤 1：搜索查看所有匹配（注意：可能返回很多结果）
python scripts/manage_members.py add --repo-search "2131" --member "zxke"

# 步骤 2：从 JSON 输出中找到目标仓库的 httpUrl 和 id
# 示例：{"index": 1, "id": 474242, "httpUrl": "https://...2131.git"}

# 步骤 3：使用具体仓库信息重试（使用 httpUrl 作为 --repo-url）
python scripts/manage_members.py add \
  --repo-url "https://codetest.iflytek.com/bofeng/2131.git" \
  --project-id 474242 \
  --member "zxke"
```

### 决策矩阵

| 场景 | 最佳方案 | 命令模式 |
|-----------|---------------|--------------------|
| 唯一的仓库名称 | `--repo-search` | `--repo-search "unique-name"` |
| 非唯一的仓库名称 | `--repo-url` + `--project-id` | `--repo-url "..." --project-id 12345` |
| 不确定仓库信息 | 先搜索，再使用完整信息 | 1. 搜索<br>2. 选择仓库<br>3. 使用 `--repo-url` + `--project-id` |
| 已知仓库 URL | `--repo-url` + `--project-id` | `--repo-url "..." --project-id 12345` |

### 为什么这样设计？
- **防止误操作**：避免对错误的仓库执行操作
- **清晰的工作流**：当存在歧义时明确展示选项
- **灵活性**：同时支持模糊搜索和精确定位

### 相关代码
- **函数**：`resolve_repo_info()`，位于 `scripts/manage_members.py`
- **行号**：~150-208
- **返回**：包含 'url' 和 'id' 键的 `dict`，或当用户需要选择时返回 `None`

---

## 3. 添加项目成员

### 接口

```
POST /ai-code/repo/addOrUpdateProjectMember
```

### 使用场景

**仅用于添加新成员**到仓库。如果成员已存在会失败。要更改已有成员的权限，请使用 `update` 命令。

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git",
  "projectId": 474190,
  "memberUserName": "zhangsan",
  "accessLevel": 4
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `projectId`（integer，**必填**）：项目的数字 ID（从搜索结果中获取）
- `memberUserName`（string，必填）：要添加的成员域账号
- `accessLevel`（integer，必填）：权限级别（见上方 accessLevel 参考）

**关键**：`projectId` 字段是成功添加成员的**必填项**。如果未提供，API 会返回 "record not found" 错误。

### 行为

如果成员已存在于仓库中，`add` 命令会返回错误，包含：
- 该成员的当前角色
- 建议使用 `update` 命令

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 16054,
    "username": "zxke",
    "login": null,
    "name": "zxke",
    "email": "zxke@iflytek.com",
    "avatarUrl": null,
    "accessLevel": 4,
    "createdAt": "2025-02-11T10:38:09.281+08:00"
  },
  "traceId": ""
}
```

### 成员已存在的响应

```json
{
  "error": "Member 'zhangsan' already exists in the repository with role 'collaborator'",
  "suggestion": "Use the 'update' command to change the member's role: python manage_members.py update --repo-search <repo> --member 'zhangsan' --role <role>",
  "member": "zhangsan",
  "current_role": "collaborator"
}
```

### 脚本用法

```bash
# 使用默认角色（collaborator，级别 4）添加
# 使用 --repo-search 时，脚本会自动提取 projectId
python manage_members.py add --repo-search "my-project" --member "zhangsan"

# 使用指定角色添加
python manage_members.py add --repo-search "my-project" --member "zhangsan" --role admin

# 使用直接仓库 URL 和显式 projectId（推荐，使用仓库搜索结果中的 httpUrl）
python manage_members.py add --repo-url "https://gitee.com/org/my-project.git" --project-id 474190 --member "zhangsan" --role guest
```

### 交互式工作流（通过 Claude 对话）

1. 如果用户提供了仓库搜索关键词：
   - 使用 `--repo-search` 调用脚本查找仓库
   - 如果恰好一个匹配：脚本自动使用该项目 ID
   - 如果多个匹配：展示列表及 ID，请用户选择
2. 如果用户提供了 `--repo-url`：如未提供 `--project-id` 则询问
3. 如果未指定角色，默认为 `collaborator`
4. 执行添加操作

### 使用 --repo-search 的工作流

1. 脚本搜索匹配关键词的仓库
2. 如果恰好一个匹配：使用搜索结果中的 `id` 作为 `projectId`
3. 如果多个匹配：显示列表并要求用户提供 `--repo-url`
4. 直接使用 `--repo-url` 时：如已知应同时提供 `--project-id`

---

## 4. 更新项目成员权限

### 接口

```
POST /ai-code/repo/addOrUpdateProjectMember
```

### 使用场景

**用于添加或更新成员权限**。直接调用 addOrUpdateProjectMember 接口，不检查成员是否已存在于仓库中。

### 行为

`update` 命令直接调用 `addOrUpdateProjectMember` 接口设置成员权限：
- 成员不存在 → 添加成员并设置权限
- 成员已存在 → 更新为新的权限级别

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 16054,
    "username": "zxke",
    "login": null,
    "name": "zxke",
    "email": "zxke@iflytek.com",
    "avatarUrl": null,
    "accessLevel": 6,
    "createdAt": "2025-02-11T10:38:09.281+08:00"
  },
  "traceId": ""
}
```

### 脚本用法

```bash
# 添加或更新成员权限为配置角色
python manage_members.py update --repo-search "my-project" --member "zhangsan" --role configurator

# 添加或更新成员权限为管理员角色
python manage_members.py update --repo-search "my-project" --member "zhangsan" --role admin

# 使用直接仓库 URL 和显式 projectId（推荐，使用仓库搜索结果中的 httpUrl）
python manage_members.py update --repo-url "https://gitee.com/org/my-project.git" --project-id 474190 --member "zhangsan" --role admin
```

---

## 5. 删除项目成员

### 接口

```
DELETE /ai-code/repo/deleteProjectMember
```

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git",
  "projectId": 474190,
  "userId": 123
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `projectId`（integer，**必填**）：项目的数字 ID（从搜索结果中获取）
- `userId`（integer，必填）：成员的 Gitee 用户 ID（由脚本自动解析）

**关键**：与添加成员类似，删除成员也**需要项目的数字 ID**（`projectId`）。如果未提供，API 会失败。

### 响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

### userId 的解析方式

用户只需提供成员的**域账号**。脚本会：
1. 调用 `getProjectMembers` 列出所有当前成员
2. 找到 `username` 或 `login` 与提供的域账号匹配的成员
3. 使用该成员的 `id` 字段作为删除调用的 `userId`

如果成员未找到，会返回错误并附带当前成员列表。

### 脚本用法

```bash
# 通过成员用户名 + 仓库搜索删除（自动提取 projectId）
python manage_members.py delete --repo-search "my-project" --member "zhangsan"

# 使用直接仓库 URL 和显式 projectId 删除（推荐，使用仓库搜索结果中的 httpUrl）
python manage_members.py delete --repo-url "https://gitee.com/org/my-project.git" --project-id 474190 --member "zhangsan"
```

### 完整工作流

1. **搜索仓库**获取项目 ID：
   ```bash
   python manage_members.py search --keyword "my-project"
   ```

2. **记录项目 ID**（如 `474190`）

3. **使用项目 ID 删除成员**（使用仓库搜索结果中的 httpUrl）：
   ```bash
   python manage_members.py delete --repo-url "https://gitee.com/org/my-project.git" --project-id 474190 --member "zhangsan"
   ```

---

## 错误响应

所有接口的错误响应格式如下：

```json
{
  "success": false,
  "code": "500",
  "message": "错误描述",
  "data": null
}
```

常见错误：
- 配置缺失或无效
- 仓库未找到
- 成员未找到（删除时）
- 权限被拒绝
- 网络连接问题
- **未提供 `projectId`**（添加/删除时）：导致 "record not found" 错误

---

## 最佳实践总结

### 添加成员

1. **添加成员时始终使用 `--project-id`**：这是最可靠的方法
2. **先搜索获取项目 ID**：使用 `--repo-search` 查找仓库并记录其 `id`
3. **处理多个匹配**：搜索返回多个仓库时，向用户展示选项
4. **从搜索结果中提取 ID**：搜索响应中每个仓库都包含 `id` 字段

### 完整工作流示例

```bash
# 步骤 1：搜索仓库
python manage_members.py search --keyword "my-project"

# 步骤 2：记录搜索结果中的项目 ID 和 httpUrl
# 示例输出："id": 474190, "httpUrl": "https://codetest.iflytek.com/yyzhu4/0311-test-repo-v2.git"

# 步骤 3：使用项目 ID 添加成员（使用 httpUrl 作为 --repo-url）
python manage_members.py add --repo-url "https://codetest.iflytek.com/yyzhu4/0311-test-repo-v2.git" --project-id 474190 --member "bofeng" --role collaborator
```

### 注意事项

- `repoType` 对于 Gitee 仓库始终为 `"GITEE"`
- `repoUrl` 是 **HTTP 克隆 URL**（`httpUrl`，如 `https://gitee.com/org/repo-name.git`）。**不要**使用 `webUrl`。
- `projectId` 是 Gitee 数据库中的数字 ID（如 `474190`）
- 搜索仓库时，脚本对仓库名称/路径进行模糊匹配
- `userName` 字段代表**当前操作者**（执行操作的人），而 `memberUserName` 代表**目标成员**（被添加的人）

## 典型场景示例（用户对话）

### 场景 1 — 查看仓库成员

```
用户：查看 sschu2 仓库的成员
AI：正在查询 sschu2 仓库成员...

✅ 查询完成！sschu2 仓库共有 5 个成员

┌────────────┬──────────┬──────────────────────────┐
│ 用户       │ 角色     │ 添加时间                 │
├────────────┼──────────┼──────────────────────────┤
│ sschu2     │ 管理员   │ 2026-03-18               │
│ minliu27   │ 协作     │ 2026-03-18               │
│ bofeng     │ 协作     │ 2026-03-26               │
│ changhan2  │ 配置     │ 2026-04-02               │
│ zxke       │ 协作     │ 2026-04-08               │
└────────────┴──────────┴──────────────────────────┘

需要添加或修改成员吗？
```

### 场景 2 — 添加成员（未指定权限，需询问）

```
用户：把 zhangsan 添加到 my-project 仓库
AI：请选择要授予 zhangsan 的权限角色：

┌──────────────┬─────────────┬──────────────────────┐
│ 角色         │ accessLevel │ 说明                 │
├──────────────┼─────────────┼──────────────────────┤
│ guest        │ 2           │ 访客 - 只读权限      │
│ collaborator │ 4           │ 协作 - 可提交代码    │
│ configurator │ 6           │ 配置 - 可管理设置    │
│ admin        │ 8           │ 管理员 - 完全控制    │
└──────────────┴─────────────┴──────────────────────┘

用户：协作
AI：正在添加成员到 my-project...

✅ 成员添加成功！

• 用户: zhangsan
• 仓库: my-project
• 角色: 协作 (accessLevel: 4)

[查看成员列表] [修改其他成员] [完成]
```

### 场景 2b — 添加成员（已指定权限）

```
用户：把 zhangsan 添加到 my-project 仓库，权限是管理员
AI：正在添加成员到 my-project...

✅ 成员添加成功！

• 用户: zhangsan
• 仓库: my-project
• 角色: 管理员 (accessLevel: 8)

[查看成员列表] [修改其他成员] [完成]
```

### 场景 2c — 修改成员权限

```
用户：把 my-project 仓库的 zhangsan 权限改为配置
AI：正在更新成员权限...

✅ 权限更新成功！

• 用户: zhangsan
• 仓库: my-project
• 角色: 配置 (accessLevel: 6)

[查看成员列表] [修改其他成员] [完成]
```

### 场景 3 — 删除成员

```
用户：从 my-project 移除 wangwu
AI：确认删除操作...

⚠️ 删除确认

即将从 my-project 仓库移除成员：
• 用户：wangwu

⚠️ 警告：移除后该用户将无法访问此仓库的内容。

[取消] [确认删除]

用户：确认删除
AI：正在执行删除...

✅ 删除成功！

wangwu 已从 my-project 仓库移除。

[查看成员列表] [添加新成员] [完成]
```

### 场景 4 — 批量添加

```
用户：把 zhangsan、lisi、wangwu 添加到 frontend-app 仓库，权限是协作
AI：好的，正在批量添加成员到 frontend-app...

✅ 批量添加完成！

┌────────────┬──────────┬──────────┐
│ 用户       │ 状态     │ 权限     │
├────────────┼──────────┼──────────┤
│ zhangsan   │ ✅ 成功  │ 协作     │
│ lisi       │ ✅ 成功  │ 协作     │
│ wangwu     │ ✅ 成功  │ 协作     │
└────────────┴──────────┴──────────┘

[查看成员列表] [完成]
```

### 输出字段说明

| 输出项 | 类型 | 说明 |
|--------|------|------|
| 用户 | String | 成员的域账号 |
| 角色 | String | 权限角色（访客/协作/配置/管理员） |
| 添加时间 | String | 成员加入仓库的时间 |
| accessLevel | Integer | 权限级别数字（2/4/6/8） |
