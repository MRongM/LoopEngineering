# Code Submission Workflow - Reference

## Overview

This workflow provides end-to-end code submission capabilities: stage changes → AI-generated commit message → commit → push → create PR. It combines local git operations with remote Gitee PR management.

**Key Features**:
- AI analyzes `git diff` to auto-generate commit messages following project convention
- Safety guardrails: diff review, sensitive file detection, user confirmation
- Environment-aware: full workflow in local, PR-only in cloud
- Integrates with existing PR management capabilities

## Prerequisites

- **Local git repository** (not available in cloud environment)
- **Changes staged** via `git add` or ready to stage
- **Task ID** (T-xxx format) from branch name or user input
- **Remote branch** already exists or will be created

## Workflow Steps

### Step 1: Environment Detection

Check if running in a local git repository:

```bash
git rev-parse --is-inside-work-tree
```

- **Exit code 0**: Local git repo → proceed with full workflow
- **Exit code non-0**: Not a git repo → only PR creation available

If not in local environment, inform user:
```
当前环境没有本地 Git 仓库，代码提交功能仅支持本地环境。
您可以使用 PR 管理功能来管理远程代码（需要代码已推送到远程分支）。
```

### Step 2: Stage Changes (if needed)

If user hasn't staged files yet, guide them:

```bash
# Stage all changes
git add .

# Or stage specific files
git add path/to/file1.py path/to/file2.py

# Check staged files
git status
```

### Step 3: Show Diff and Confirm

Display the staged changes to user:

```bash
git diff --staged
```

Ask user to confirm:
- "以上是即将提交的代码变更，是否继续？"
- If user says no, stop workflow

### Step 4: Sensitive File Check

Check if any sensitive files are staged:

**Sensitive patterns**:
- `.env`, `.env.*`
- `*.key`, `*.pem`, `*.crt`
- `credentials.*`, `*credential*`
- `*.secret`, `*secret*`
- `token*`, `*token*`
- `password*`, `*password*`

```bash
git diff --staged --name-only | grep -E '\.(env|key|pem|crt|secret)$|credentials|token|password'
```

If sensitive files detected:
```
⚠️ 检测到敏感文件：
- .env
- config/credentials.json

这些文件可能包含密钥、密码等敏感信息，不应提交到代码仓库。
是否继续？（不推荐）
```

### Step 5: Generate Commit Message

Run the commit message generator:

```bash
cd {SKILL_INSTALL_PATH}
git diff --staged | python scripts/generate_commit_msg.py --task-id T-xxx
```

**Parameters**:
- `--task-id T-xxx`: Task ID (required if not in branch name)
- `--branch-name feature/T-xxx-desc`: Extract task ID from branch name
- Input: `git diff --staged` output via stdin

**Output** (JSON):
```json
{
  "commit_message": "feat(dev-assistant): T-123 新增代码提交工作流",
  "type": "feat",
  "scope": "dev-assistant",
  "task_id": "T-123",
  "description": "新增代码提交工作流",
  "confidence": 0.9,
  "type_reason": "新增文件: generate_commit_msg.py, submit_code.md",
  "scope_reason": "变更文件主要位于 dev-assistant/ 目录",
  "task_reason": "从 --task-id 参数获取: T-123",
  "diff_summary": {
    "files_changed": 3,
    "additions": 245,
    "deletions": 12,
    "new_files": 2,
    "modified_files": 1,
    "deleted_files": 0
  }
}
```

**If error** (no task ID, no files, etc.):
```json
{
  "error": "错误描述",
  "commit_message": null,
  "confidence": 0.0
}
```

### Step 6: Show Generated Message and Confirm

Display the generated commit message to user:

```
📝 生成的 Commit Message：

feat(dev-assistant): T-123 新增代码提交工作流

置信度: 0.9
类型推理: 新增文件: generate_commit_msg.py, submit_code.md
范围推理: 变更文件主要位于 dev-assistant/ 目录

变更统计:
- 文件数: 3
- 新增行: 245
- 删除行: 12

是否使用此 commit message？
1. 是，直接使用
2. 否，我要修改
3. 取消提交
```

**If user chooses to edit**:
- Ask user to provide the corrected commit message
- Validate format: `类型(范围): T-xxx 描述`
- If invalid, show error and ask again

**If confidence < 0.7**:
- Add warning: "⚠️ 置信度较低，建议检查 commit message 是否准确"

### Step 7: Commit Locally

Execute the commit:

```bash
git commit -m "feat(dev-assistant): T-123 新增代码提交工作流"
```

Confirm success:
```
✅ 代码已提交到本地仓库
Commit: a1b2c3d feat(dev-assistant): T-123 新增代码提交工作流
```

### Step 8: Push to Remote

Get current branch name:

```bash
git branch --show-current
```

Push to remote:

```bash
git push origin <branch-name>
```

**If push fails** (remote has new commits):

```
❌ Push 失败：远程分支有新提交

建议操作：
1. 拉取远程变更并 rebase
   git pull --rebase origin <branch-name>

2. 如果有冲突，解决冲突后继续
   git add <resolved-files>
   git rebase --continue

3. 重新推送
   git push origin <branch-name>

是否自动执行 git pull --rebase？
```

If user confirms, execute:
```bash
git pull --rebase origin <branch-name>
```

Check for conflicts:
```bash
git status | grep "both modified"
```

If conflicts exist:
```
⚠️ 检测到合并冲突，需要手动解决：
<list of conflicted files>

请在编辑器中解决冲突后，运行：
git add <resolved-files>
git rebase --continue
git push origin <branch-name>
```

### Step 9: Create PR (Optional)

After successful push, ask user:
```
✅ 代码已推送到远程分支: <branch-name>

是否创建 Pull Request？
1. 是，创建 PR
2. 否，稍后手动创建
```

If user chooses to create PR, use existing `manage_prs.py`:

```bash
cd {SKILL_INSTALL_PATH}
python scripts/manage_prs.py create \
  --repo-search "<repo-name>" \
  --source-branch "<current-branch>" \
  --target-branch "master" \
  --title "<PR-title>" \
  --description "<PR-description>"
```

**PR title suggestion**: Use commit message as default
**PR description suggestion**: Include commit message + diff summary

## Safety Checks Summary

| Check Point | Action |
|-------------|--------|
| Environment detection | Verify local git repo exists |
| Staged files | Show diff, ask confirmation |
| Sensitive files | Warn if detected, ask confirmation |
| Commit message | Show generated message, allow editing |
| Push conflicts | Guide user through rebase process |
| Never force push | Always use `git push`, never `git push -f` |

## Error Handling

### Error: No staged files

```
❌ 没有检测到暂存的文件变更

请先使用 git add 暂存文件：
  git add .                    # 暂存所有变更
  git add path/to/file.py      # 暂存指定文件
```

### Error: No task ID

```
❌ 无法提取任务编号 (T-xxx)

请提供任务编号：
  --task-id T-123

或确保分支名包含任务编号：
  feature/T-123-description
  bugfix/T-456-fix-login
```

### Error: Invalid commit message format

```
❌ Commit message 格式不符合规范

正确格式: 类型(范围): T-xxx 任务简述

类型: feat, fix, refactor, docs, chore
范围: Agent 目录名 (kebab-case)
任务编号: T-xxx 格式

示例:
  feat(dev-assistant): T-123 新增登录功能
  fix(pa): T-456 修复日期显示错误
```

### Error: Push rejected (non-fast-forward)

```
❌ Push 被拒绝：远程分支有新提交

解决方案：
1. 拉取并 rebase:
   git pull --rebase origin <branch>

2. 如有冲突，解决后继续:
   git add <files>
   git rebase --continue

3. 重新推送:
   git push origin <branch>

⚠️ 不要使用 git push -f (force push)
```

### Error: Network failure

```
❌ 网络请求失败

可能原因:
- 网络连接问题
- 代理配置问题
- Gitee 服务不可用

建议:
1. 检查网络连接
2. 检查代理设置 (HTTP_PROXY, HTTPS_PROXY)
3. 稍后重试
```

## Complete Workflow Example

```bash
# 1. Check environment
$ git rev-parse --is-inside-work-tree
true

# 2. Stage changes
$ git add dev-assistant/skills/manage-git-repo/scripts/generate_commit_msg.py
$ git add dev-assistant/skills/manage-git-repo/references/submit_code.md

# 3. Show diff
$ git diff --staged
[... diff output ...]

# 4. Check sensitive files
$ git diff --staged --name-only | grep -E '\.(env|key|pem)'
[no output - safe]

# 5. Generate commit message
$ git diff --staged | python scripts/generate_commit_msg.py --task-id T-001
{
  "commit_message": "feat(dev-assistant): T-001 新增代码提交工作流",
  "type": "feat",
  "scope": "dev-assistant",
  "task_id": "T-001",
  "confidence": 0.9,
  ...
}

# 6. Commit
$ git commit -m "feat(dev-assistant): T-001 新增代码提交工作流"
[feature/T-001-submit-code a1b2c3d] feat(dev-assistant): T-001 新增代码提交工作流
 2 files changed, 245 insertions(+), 12 deletions(-)

# 7. Push
$ git push origin feature/T-001-submit-code
Enumerating objects: 8, done.
...
To https://gitee.com/org/repo.git
   abc123..a1b2c3d  feature/T-001-submit-code -> feature/T-001-submit-code

# 8. Create PR
$ python scripts/manage_prs.py create \
    --repo-search "openclaw-subAgent" \
    --source-branch "feature/T-001-submit-code" \
    --target-branch "master" \
    --title "feat(dev-assistant): T-001 新增代码提交工作流"
{
  "success": true,
  "data": "https://gitee.com/org/repo/pulls/123"
}
```

## Integration with Existing Capabilities

This workflow integrates seamlessly with existing `manage-git-repo` capabilities:

| Existing Capability | Integration Point |
|---------------------|-------------------|
| Branch management | Create feature branch before committing |
| Commit queries | View commit history after push |
| PR management | Create PR after push (Step 9) |
| Member management | Check permissions before push |

## Best Practices

1. **Always review diff before committing** - Catch unintended changes
2. **Use descriptive task IDs** - Link commits to tasks for traceability
3. **Keep commits atomic** - One logical change per commit
4. **Write clear descriptions** - Help reviewers understand changes
5. **Test before committing** - Ensure code works locally
6. **Pull before push** - Avoid conflicts with team members
7. **Never commit sensitive data** - Use .gitignore and pre-commit checks

## Limitations

- **Cloud environment**: Only PR creation available (no local git operations)
- **Binary files**: Commit message generation works best with text files
- **Large diffs**: Very large diffs (>10k lines) may reduce detection accuracy
- **Multi-language repos**: Scope detection assumes single primary directory
