# 列出仓库 - API 参考

## 概述

查询和列出仓库，支持关键词搜索和分页。

## 列出仓库接口

```
POST /ai-code/repo/getRepoList
```

## 请求头

```
Content-Type: application/json; charset=UTF-8
```


## 请求体

```json
{
  "repoType": "GITEE",
  "search": "",
  "hasStat": 0,
  "currentPage": 1,
  "pageSize": 20,
  "type": "all"
}
```

### 参数

| 参数 | 类型 | 必填 | 说明 |
|-----------|------|----------|----------------|
| repoType | string | 是 | 仓库类型，必须为 "GITEE" |
| search | string | 否 | 搜索关键词，对仓库名称/路径进行模糊搜索 |
| type | string | 否 | 按类型过滤仓库。见下方**类型值**。省略时返回全部。 |
| hasStat | integer | 否 | 是否返回代码统计信息（0：否，1：是），默认：0 |
| currentPage | integer | 否 | 页码（默认：1） |
| pageSize | integer | 否 | 每页数量（默认：20） |

### 类型值

| 值 | 说明 |
|-------|----------------|
| `all` | 全部 — 用户可见的所有仓库 |
| `created` | 我拥有的 — 用户创建/拥有的仓库 |
| `participated` | 我参与的 — 用户参与但不拥有的仓库 |
| `favorites` | 我的星标 — 用户标星的仓库 |
| `inner_source` | 内部公开 — 内部公开（内源）仓库 |

## 响应

### 成功响应 (200 OK)

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "repoVOPage": {
      "total": 1,
      "totalPages": 1,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "feignType": "giteeProjectVO",
          "id": 474248,
          "name": "sschu2",
          "path": "sschu2",
          "description": "",
          "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/code/",
          "sshUrl": "ssh://git@codetest.iflytek.com:30004/sschu2/sschu2.git",
          "httpUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
          "fullName": "sschu2(sschu2/sschu2)",
          "fullPath": "sschu2/sschu2",
          "parentId": 2380,
          "createdTime": "2026-03-18T16:56:35+08:00",
          "ownerName": "sschu2",
          "commitNum": 0,
          "totalLines": 0
        }
      ]
    },
    "repoType": "GITEE"
  },
  "traceId": ""
}
```

### 错误响应

```json
{
  "success": false,
  "code": "500",
  "message": "查询仓库列表失败",
  "data": null
}
```

## 错误码

| 错误码 | 说明 |
|------|----------------|
| 500 | 查询失败，可能原因：网络错误、权限不足等 |

## 示例

### 示例 1：列出所有仓库（第一页）

**请求**：
```json
{
  "repoType": "GITEE",
  "search": "",
  "hasStat": 0,
  "currentPage": 1,
  "pageSize": 20
}
```

**响应**：见上方成功响应。

### 示例 2：按关键词搜索仓库

**请求**：
```json
{
  "repoType": "GITEE",
  "search": "awesome",
  "hasStat": 0,
  "currentPage": 1,
  "pageSize": 20
}
```

**响应**：返回名称或路径中包含 "awesome" 的仓库（模糊搜索）。

### 示例 3：列出并包含代码统计

**请求**：
```json
{
  "repoType": "GITEE",
  "search": "",
  "hasStat": 1,
  "currentPage": 1,
  "pageSize": 20
}
```

**响应**：返回仓库及附加的代码统计信息（提交数、分支数等）。

### 示例 4：分页（第二页）

**请求**：
```json
{
  "repoType": "GITEE",
  "search": "",
  "hasStat": 0,
  "currentPage": 2,
  "pageSize": 10
}
```

**响应**：返回第二页，每页 10 条。

### 示例 5：按仓库类型过滤 — 我拥有的仓库

**请求**：
```json
{
  "repoType": "GITEE",
  "search": "",
  "hasStat": 0,
  "currentPage": 1,
  "pageSize": 20,
  "type": "created"
}
```

**响应**：仅返回当前用户创建/拥有的仓库。

### 示例 6：按仓库类型过滤 — 星标仓库

**请求**：
```json
{
  "repoType": "GITEE",
  "search": "",
  "hasStat": 0,
  "currentPage": 1,
  "pageSize": 20,
  "type": "favorites"
}
```

**响应**：返回当前用户标星的仓库。

### 示例 7：结合类型过滤和关键词搜索

**请求**：
```json
{
  "repoType": "GITEE",
  "search": "awesome",
  "hasStat": 0,
  "currentPage": 1,
  "pageSize": 20,
  "type": "participated"
}
```

**响应**：返回名称或路径中包含 "awesome" 的仓库，仅限用户参与的。

## 仓库对象字段

| 字段 | 类型 | 说明 |
|-------|------|----------------|
| id | integer | 仓库 ID |
| name | string | 仓库名称 |
| path | string | 仓库路径（URL 标识） |
| description | string | 仓库描述 |
| webUrl | string | 仓库 Web URL（浏览器访问） |
| sshUrl | string | Git SSH 克隆 URL |
| httpUrl | string | Git HTTP 克隆 URL（以 .git 结尾）— **在其他 API 调用中作为 `repoUrl` 使用** |
| fullName | string | 仓库全名（含命名空间） |
| fullPath | string | 仓库完整路径（含命名空间） |
| parentId | integer | 父级命名空间 ID |
| ownerName | string | 仓库拥有者用户名 |
| createdTime | string | 创建时间（ISO 8601 格式） |
| commitNum | integer | 提交数量 |
| totalLines | integer | 代码总行数 |

## 脚本用法

```bash
# 列出所有仓库（默认每页数量）
python scripts/list_repos.py

# 按关键词搜索仓库
python scripts/list_repos.py --search "awesome"

# 按类型过滤：我拥有的仓库
python scripts/list_repos.py --type created

# 按类型过滤：我参与的仓库
python scripts/list_repos.py --type participated

# 按类型过滤：星标仓库
python scripts/list_repos.py --type favorites

# 按类型过滤：内部公开仓库
python scripts/list_repos.py --type inner_source

# 结合类型过滤和关键词搜索
python scripts/list_repos.py --type created --search "awesome"

# 列出并包含代码统计
python scripts/list_repos.py --has-stat

# 第二页，每页 10 条
python scripts/list_repos.py --page 2 --page-size 10

# 显示详细信息
python scripts/list_repos.py --show-details

# 输出原始 JSON
python scripts/list_repos.py --json
```

## 注意事项

- `repoType` 对于 Gitee 仓库始终为 "GITEE"
- `search` 对仓库名称和路径进行模糊匹配
- `type` 过滤返回的仓库范围；省略时 API 返回所有可见仓库
- 有效的 `type` 值：`all`、`created`、`participated`、`favorites`、`inner_source`
- 通过 `currentPage` 和 `pageSize` 支持分页
- 响应数据嵌套在 `data.repoVOPage.data` 中
- `ownerName` 字段表示仓库拥有者
- 时间戳字段为 `createdTime`（ISO 8601 格式）
- 对于大量结果集，使用分页提升性能
- **`httpUrl`**（如 `https://codetest.iflytek.com/sschu2/sschu2.git`）是在分支、PR、提交和成员 API 中作为 `repoUrl` 传递的值。**不要**在这些 API 调用中使用 `webUrl`。

## 典型场景示例（用户对话）

### 示例 1 — 搜索仓库

```
用户：搜索 sschu2 仓库
AI：正在查询仓库...

✅ 查询完成！找到 1 个仓库

┌──────────┬──────────┬──────────────────────────────────────────────┬────────────────────┐
│ 仓库名称 │ 拥有者   │ 仓库地址                                     │ 创建时间           │
├──────────┼──────────┼──────────────────────────────────────────────┼────────────────────┤
│ sschu2   │ sschu2   │ https://codetest.iflytek.com/sschu2/sschu2   │ 2026-03-18         │
└──────────┴──────────┴──────────────────────────────────────────────┴────────────────────┘

[查看详情] [筛选] [下一页] [创建新仓库]
```

### 示例 2 — 列出我拥有的仓库

```
用户：列出我拥有的仓库
AI：正在查询您拥有的仓库...

✅ 查询完成！找到 3 个仓库

┌──────────────────┬──────────┬──────────────────────────────────────────────┬────────────────────┐
│ 仓库名称         │ 拥有者   │ 仓库地址                                     │ 创建时间           │
├──────────────────┼──────────┼──────────────────────────────────────────────┼────────────────────┤
│ my-project       │ zhangsan │ https://codetest.iflytek.com/zhangsan/my-... │ 2026-03-10         │
│ backend-service  │ zhangsan │ https://codetest.iflytek.com/zhangsan/ba-... │ 2026-02-20         │
│ frontend-app     │ zhangsan │ https://codetest.iflytek.com/zhangsan/fr-... │ 2026-01-15         │
└──────────────────┴──────────┴──────────────────────────────────────────────┴────────────────────┘

[查看详情] [筛选] [下一页] [创建新仓库]
```

### 输出字段说明

| 输出项 | 类型 | 说明 |
|--------|------|------|
| 仓库名称 | String | 仓库的显示名称 |
| 拥有者 | String | 仓库所属用户或组织 |
| 仓库地址 | String | 仓库的 Web 访问地址（webUrl） |
| 创建时间 | String | 仓库创建日期 |
| 仓库ID | Integer | 仓库数字 ID（用于后续 API 调用） |
| httpUrl | String | Git HTTP 克隆地址（用于其他 API 的 repoUrl 参数） |
