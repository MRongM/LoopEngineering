# 管理 PR - API 参考

## 概述

管理 Gitee 仓库的 Pull Request（合并请求）：创建、关闭、列出、详情、接受和更新 PR。所有操作都通过 BFF 层，实现在 `scripts/manage_prs.py` 中。**不要**创建其他文件、使用 curl 或编写临时 Python 脚本。

## 重要事项

1. 所有 PR API 共用同一个脚本 `manage_prs.py`，通过子命令（`create`、`close`、`list`、`detail`、`accept`、`update`）区分。
2. 用户只需提供**仓库名称/搜索关键词**。脚本会自动解析仓库 URL。
3. 创建 PR 时，源分支和目标分支均为必填，同时需要标题。
4. 更新 PR 时，`--state-event` 为必填（可以是 `closed` 或 `opened`）。

## 通用请求头

```
Content-Type: application/json; charset=UTF-8
Authorization: Bearer <access_token>
```


---

## 1. 创建 Pull Request（合并请求）

### 接口

```
POST /ai-code/pr/mergeRequest
```

### 请求体

```json
{
  "repoType": "gitee",
  "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "sourceBranch": "feature/my-feature",
  "targetBranch": "master",
  "title": "Add new feature for user authentication",
  "description": "This PR adds OAuth2 support for user login.\nIncludes refresh token handling and session management.",
  "user": "zhangsan"
}
```

### 参数

- `repoType`（string，必填）：始终为 `"gitee"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `sourceBranch`（string，必填）：包含待合并变更的分支（"来源"分支）
- `targetBranch`（string，必填）：变更将合并到的分支（"目标"分支）
- `title`（string，必填）：Pull Request 的标题
- `description`（string，可选）：PR 的详细描述，支持 Markdown
- `user`（string，可选）：创建 PR 的用户名

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/3",
  "traceId": ""
}
```

### 脚本用法

```bash
# 通过仓库搜索关键词创建 PR
python scripts/manage_prs.py create --repo-search "my-project" --source-branch "feature/my-feature" --target-branch "master" --title "Add new feature"

# 使用直接仓库 URL 创建 PR（使用仓库搜索结果中的 httpUrl）
python scripts/manage_prs.py create --repo-url "https://gitee.com/org/my-project.git" --source-branch "feature/my-feature" --target-branch "master" --title "Add new feature"

# 创建带描述的 PR
python scripts/manage_prs.py create --repo-search "my-project" --source-branch "dev" --target-branch "master" --title "Merge dev to master" --description "This PR includes all changes for sprint 1"

# 创建 PR 并指定用户
python scripts/manage_prs.py create --repo-search "my-project" --source-branch "hotfix/bug-fix" --target-branch "master" --title "Fix critical bug" --user "zhangsan"
```

---

## 2. 关闭 Pull Request（合并请求）

### 接口

```
POST /ai-code/pr/closeMergeRequest
```

### 请求体

```json
{
  "repoType": "gitee",
  "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "mergeRequestIid": 1,
  "user": "zhangsan"
}
```

### 参数

- `repoType`（string，必填）：始终为 `"gitee"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `mergeRequestIid`（integer，必填）：要关闭的合并请求 IID（内部 ID）
- `user`（string，可选）：关闭 PR 的用户名

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": "PR 成功关闭",
  "traceId": ""
}
```

### 脚本用法

```bash
# 通过仓库搜索关键词关闭 PR
python scripts/manage_prs.py close --repo-search "my-project" --merge-request-iid 123

# 使用直接仓库 URL 关闭 PR（使用仓库搜索结果中的 httpUrl）
python scripts/manage_prs.py close --repo-url "https://gitee.com/org/my-project.git" --merge-request-iid 123

# 关闭 PR 并指定用户
python scripts/manage_prs.py close --repo-search "my-project" --merge-request-iid 123 --user "zhangsan"
```

---

## 3. 列出 Pull Request

### 接口

```
POST /ai-code/pr/getMergeRequestList
```

### 请求体

```json
{
  "repoType": "gitee",
  "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "state": "opened",
  "sourceBranch": "feature/my-feature",
  "targetBranch": "master",
  "search": "feature",
  "orderBy": "created_at",
  "sort": "desc",
  "currentPage": 1,
  "pageSize": 20
}
```

### 参数

**必填：**
- `repoType`（string）：始终为 `"gitee"`
- `repoUrl`（string）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）

**可选：**
- `state`（string）：按状态过滤 - `opened`、`closed`、`merged` 或 `all`
- `sourceBranch`（string）：按源分支名称过滤
- `targetBranch`（string）：按目标分支名称过滤
- `search`（string）：在标题/描述中搜索关键词
- `orderBy`（string）：排序字段 - `created_at` 或 `updated_at`
- `sort`（string）：排序方向 - `asc` 或 `desc`
- `currentPage`（integer）：页码，默认 1
- `pageSize`（integer）：每页数量，默认 20

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "mergeRequestPage": {
      "total": 10,
      "totalPages": 1,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "id": 285444,
          "iid": 1,
          "projectId": 474248,
          "title": "Add new feature",
          "description": "",
          "state": "opened",
          "createdAt": "2026-03-23T10:30:00+08:00",
          "updatedAt": "2026-03-23T10:30:00+08:00",
          "targetBranch": "master",
          "sourceBranch": "feature/my-feature",
          "authorName": "zhangsan",
          "mergeStatus": "can_be_merged",
          "sha": "",
          "shouldRemoveSourceBranch": false,
          "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/1",
          "changesCount": "",
          "mergedAt": null,
          "closedAt": null
        }
      ]
    },
    "repoType": "gitee"
  },
  "traceId": ""
}
```

### 脚本用法

```bash
# 列出所有 PR（基本查询）
python scripts/manage_prs.py list --repo-search "my-project"

# 按状态过滤列出
python scripts/manage_prs.py list --repo-search "my-project" --state opened

# 按分支过滤列出
python scripts/manage_prs.py list --repo-search "my-project" --source-branch "feature/*" --target-branch "master"

# 搜索并分页列出
python scripts/manage_prs.py list --repo-search "my-project" --search "feature" --page 1 --page-size 10

# 排序列出
python scripts/manage_prs.py list --repo-search "my-project" --order-by updated_at --sort desc
```

### Claude 工作流
1. 首次仅使用仓库参数查询
2. 向用户展示结果
3. 询问是否需要应用过滤条件（状态、分支、搜索、排序、分页）
4. 如需要，使用选定的过滤条件重新查询

---

## 4. 获取 Pull Request 详情

### 接口

```
POST /ai-code/pr/getMergeRequest
```

### 请求体

```json
{
  "repoType": "gitee",
  "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "mergeRequestIid": 1
}
```

### 参数

- `repoType`（string，必填）：始终为 `"gitee"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `mergeRequestIid`（integer，必填）：合并请求的 IID

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 285446,
    "iid": 1,
    "projectId": 474248,
    "title": "Add new feature",
    "description": "This PR adds OAuth2 support",
    "state": "opened",
    "createdAt": "2026-03-23T10:30:00+08:00",
    "updatedAt": "2026-03-23T10:30:00+08:00",
    "targetBranch": "master",
    "sourceBranch": "feature/my-feature",
    "authorName": "zhangsan",
    "mergeStatus": "can_be_merged",
    "sha": "",
    "shouldRemoveSourceBranch": false,
    "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/1",
    "changesCount": "",
    "mergedAt": null,
    "closedAt": null
  },
  "traceId": ""
}
```

### 脚本用法

```bash
# 通过仓库搜索获取 PR 详情
python scripts/manage_prs.py detail --repo-search "my-project" --merge-request-iid 1

# 使用直接仓库 URL 获取 PR 详情（使用仓库搜索结果中的 httpUrl）
python scripts/manage_prs.py detail --repo-url "https://gitee.com/org/my-project.git" --merge-request-iid 1
```

### Claude 工作流
1. 使用仓库 + merge-request-iid 查询
2. 向用户展示详细结果
3. 询问是否需要其他信息

---

## 5. 接受/合并 Pull Request

### 接口

```
POST /ai-code/pr/acceptMergeRequest
```

### 请求体

```json
{
  "repoType": "gitee",
  "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "mergeRequestIid": 1,
  "mergeCommitMessage": "Merge feature branch",
  "squashCommitMessage": "Add new feature (squashed)",
  "squash": false,
  "shouldRemoveSourceBranch": false
}
```

### 参数

**必填：**
- `repoType`（string）：始终为 `"gitee"`
- `repoUrl`（string）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `mergeRequestIid`（integer）：要接受的合并请求 IID

**可选：**
- `mergeCommitMessage`（string）：自定义合并提交消息
- `squashCommitMessage`（string）：自定义 squash 提交消息
- `squash`（boolean）：是否将提交压缩为一个
- `shouldRemoveSourceBranch`（boolean）：合并后是否删除源分支

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

### 脚本用法

```bash
# 基本合并
python scripts/manage_prs.py accept --repo-search "my-project" --merge-request-iid 1

# 使用自定义消息合并
python scripts/manage_prs.py accept --repo-search "my-project" --merge-request-iid 1 --merge-commit-message "Merge feature branch"

# Squash 合并
python scripts/manage_prs.py accept --repo-search "my-project" --merge-request-iid 1 --squash --squash-commit-message "Add new feature"

# 合并并删除源分支
python scripts/manage_prs.py accept --repo-search "my-project" --merge-request-iid 1 
```

### Claude 工作流
1. 询问用户是否需要添加可选参数
2. 展示选项：自定义合并消息、squash 合并、删除源分支
3. 使用选定的选项执行

---

## 6. 更新 Pull Request

### 接口

```
POST /ai-code/pr/updateMergeRequest
```

### 请求体

```json
{
  "repoType": "gitee",
  "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "mergeRequestIid": 1,
  "stateEvent": "closed",
  "title": "Updated title",
  "description": "Updated description",
}
```

### 参数

**必填：**
- `repoType`（string）：始终为 `"gitee"`
- `repoUrl`（string）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `mergeRequestIid`（integer）：要更新的合并请求 IID
- `stateEvent`（string）：状态事件 - `closed` 或 `opened`

**可选：**
- `title`（string）：PR 的新标题
- `description`（string）：PR 的新描述

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 285448,
    "iid": 1,
    "projectId": 474248,
    "title": "Updated title",
    "description": "",
    "state": "closed",
    "createdAt": "2026-03-23T10:30:00+08:00",
    "updatedAt": "2026-03-23T11:00:00+08:00",
    "targetBranch": "master",
    "sourceBranch": "feature/my-feature",
    "authorName": "zhangsan",
    "mergeStatus": "can_be_merged",
    "sha": "",
    "shouldRemoveSourceBranch": false,
    "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/1",
    "changesCount": "",
    "mergedAt": null,
    "closedAt": "2026-03-23T11:00:00+08:00"
  },
  "traceId": ""
}
```

### 脚本用法

```bash
# 关闭 PR（推荐方式）
python scripts/manage_prs.py update --repo-search "my-project" --merge-request-iid 1 --state-event closed

# 重新打开 PR
python scripts/manage_prs.py update --repo-search "my-project" --merge-request-iid 1 --state-event opened

# 更新标题和描述
python scripts/manage_prs.py update --repo-search "my-project" --merge-request-iid 1 --state-event opened --title "New title" --description "New description"
```

### Claude 工作流
1. 询问用户想更新什么
2. 展示选项：修改状态（关闭/重新打开）、更新标题、更新描述
3. 使用选定的选项执行

---

## 处理多个仓库匹配

当 `--repo-search` 匹配到多个仓库时，脚本返回退出码 1 并附带 JSON 响应列出所有匹配项。这是预期行为。

```json
{
  "multiple_repos": [
    {
      "index": 1,
      "id": 474192,
      "name": "my-project-v2",
      "path": "my-project-v2",
      "httpUrl": "https://codetest.iflytek.com/my-project-v2.git",
      "description": ""
    },
    {
      "index": 2,
      "id": 474190,
      "name": "my-project",
      "path": "my-project",
      "httpUrl": "https://codetest.iflytek.com/my-project.git",
      "description": ""
    }
  ],
  "message": "Found 2 repositories. Please select one by providing --repo-url with the httpUrl value."
}
```

将列表展示给用户，请用户通过索引选择，然后使用对应的 `httpUrl` 作为 `--repo-url`。

---

## 错误响应

所有接口的错误响应格式如下：

```json
{
  "success": false,
  "code": "500",
  "message": "错误描述",
  "data": null,
  "traceId": ""
}
```

常见错误：
- 配置缺失或无效
- 仓库未找到
- 分支未找到（无效的 `--source-branch` 或 `--target-branch`）
- 合并请求未找到（无效的 `--merge-request-iid`）
- 权限被拒绝
- 网络连接问题
- PR 创建失败（如分支相同、分支间无提交等）
- PR 关闭失败（如 PR 已合并或已关闭）
- PR 合并失败（如存在合并冲突）
