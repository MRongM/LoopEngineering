# 管理标签 - API 参考

## 概述

管理 Gitee 仓库标签：列出、创建和删除。所有操作都通过 BFF 层，实现在 `scripts/manage_tags.py` 中。**不要**创建其他文件、使用 curl 或编写临时 Python 脚本。

## 重要事项

1. 所有标签 API 共用同一个脚本 `manage_tags.py`，通过子命令（`list`、`create`、`delete`）区分。
2. 用户只需提供**仓库名称/搜索关键词/标签名称**。脚本会自动解析仓库 URL。
3. 标签列表支持通过 `--page` 和 `--page-size` 分页。
4. 创建标签时，`--tag-name` 和 `--ref`（分支或提交 SHA）为必填。

## 通用请求头

```
Content-Type: application/json; charset=UTF-8
```


---

## 1. 列出标签

### 接口

```
POST /ai-code/repo/getRepoTagList
```

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git",
  "search": "",
  "currentPage": 1,
  "pageSize": 20
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `search`（string，可选）：按标签名称模糊搜索的关键词
- `currentPage`（integer，可选）：页码，默认 1
- `pageSize`（integer，可选）：每页数量，默认 20

### 响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "tagVOPage": {
      "total": 3,
      "totalPages": 1,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "feignType": "giteeTagVO",
          "name": "v1.0.0",
          "tagMessage": "Release version 1.0.0",
          "protectedTag": false,
          "commitId": "abc123",
          "committer": "someone",
          "commitTime": "2026-03-01T10:00:00+08:00",
          "commitMessage": "init commit"
        },
        {
          "feignType": "giteeTagVO",
          "name": "v0.9.0",
          "tagMessage": "Beta release",
          "protectedTag": false,
          "commitId": "def456",
          "committer": "someone",
          "commitTime": "2026-02-15T08:30:00+08:00",
          "commitMessage": "feat: add new feature"
        }
      ]
    },
    "repoType": "GITEE"
  },
  "traceId": ""
}
```

### 脚本用法

```bash
# 通过仓库搜索关键词列出标签
python scripts/manage_tags.py list --repo-search "my-project"

# 使用直接仓库 URL 列出标签（使用仓库搜索结果中的 httpUrl）
python scripts/manage_tags.py list --repo-url "https://gitee.com/org/my-project.git"

# 使用搜索过滤和分页列出标签
python scripts/manage_tags.py list --repo-search "my-project" --search "v1" --page 1 --page-size 10
```

---

## 2. 创建标签

### 接口

```
POST /ai-code/repo/createTag
```

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git",
  "tagName": "v1.0.0",
  "ref": "master",
  "message": "Release version 1.0.0"
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `tagName`（string，必填）：要创建的新标签名称
- `ref`（string，必填）：要基于的分支名称或提交 SHA
- `message`（string，可选）：标签消息/描述

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

### 脚本用法

```bash
# 从 master 创建标签
python scripts/manage_tags.py create --repo-search "my-project" --tag-name "v1.0.0" --ref "master"

# 创建带消息的标签
python scripts/manage_tags.py create --repo-search "my-project" --tag-name "v1.0.0" --ref "master" --message "Release version 1.0.0"

# 使用直接仓库 URL 创建（使用仓库搜索结果中的 httpUrl）
python scripts/manage_tags.py create --repo-url "https://gitee.com/org/my-project.git" --tag-name "v2.0.0" --ref "dev" --message "Major release"
```

---

## 3. 删除标签

### 接口

```
POST /ai-code/repo/deleteTag
```

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git",
  "tagName": "v1.0.0-beta"
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL
- `tagName`（string，必填）：要删除的标签名称

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

### 脚本用法

```bash
# 通过仓库搜索关键词删除标签
python scripts/manage_tags.py delete --repo-search "my-project" --tag-name "v1.0.0-beta"

# 使用直接仓库 URL 删除
python scripts/manage_tags.py delete --repo-url "https://gitee.com/org/my-project.git" --tag-name "v1.0.0-beta"
```

---

## 处理多个仓库匹配

当 `--repo-search` 匹配到多个仓库时，脚本返回退出码 1 并附带 JSON 响应列出所有匹配项。这是预期行为。

```json
{
  "multiple_repos": [
    {
      "index": 1,
      "id": 474192,
      "name": "my-project-v2",
      "path": "my-project-v2",
      "httpUrl": "https://codetest.iflytek.com/my-project-v2.git",
      "description": ""
    },
    {
      "index": 2,
      "id": 474190,
      "name": "my-project",
      "path": "my-project",
      "httpUrl": "https://codetest.iflytek.com/my-project.git",
      "description": ""
    }
  ],
  "message": "Found 2 repositories. Please select one by providing --repo-url with the httpUrl value."
}
```

将列表展示给用户，请用户通过索引选择，然后使用对应的 `httpUrl` 作为 `--repo-url`。

---

## 错误响应

所有接口的错误响应格式如下：

```json
{
  "success": false,
  "code": "500",
  "message": "错误描述",
  "data": null,
  "traceId": ""
}
```

常见错误：
- 配置缺失或无效
- 仓库未找到
- 标签未找到（删除时无效的 `--tag-name`）
- 标签已存在（创建时重复的 `--tag-name`）
- 无效的 ref（分支或提交不存在）
- 权限被拒绝
- 网络连接问题
