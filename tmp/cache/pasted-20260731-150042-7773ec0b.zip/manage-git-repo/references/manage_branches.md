# 管理分支 - API 参考

## 概述

管理 Gitee 仓库分支：列出、创建和删除。所有操作都通过 BFF 层，实现在 `scripts/manage_branches.py` 中。**不要**创建其他文件、使用 curl 或编写临时 Python 脚本。

## 重要事项

1. 所有分支 API 共用同一个脚本 `manage_branches.py`，通过子命令（`list`、`create`、`delete`）区分。
2. 用户只需提供**仓库名称/搜索关键词/分支名称**。脚本会自动解析仓库 URL。
3. 分支列表支持通过 `--page` 和 `--page-size` 分页。
4. 创建分支时，`--from-branch`（源分支）和 `--to-branch`（目标分支）均为必填。

## 通用请求头

```
Content-Type: application/json; charset=UTF-8
```


---

## 1. 列出分支

### 接口

```
POST /ai-code/repo/getRepoBranchList
```

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git",
  "search": "",
  "currentPage": 1,
  "pageSize": 20
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `search`（string，可选）：按分支名称模糊搜索的关键词
- `currentPage`（integer，可选）：页码，默认 1
- `pageSize`（integer，可选）：每页数量，默认 20

### 响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "branchVOPage": {
      "total": 5,
      "totalPages": 1,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "feignType": "giteeCommitVO",
          "name": "master",
          "commitId": "abc123",
          "committer": "zhangsan",
          "commitTime": "2026-03-01T10:00:00+08:00",
          "commitMessage": "init commit",
          "protectedBranch": true,
          "defaultBranch": true,
          "webUrl": "https://codetest.iflytek.com/osc/_source/org/my-project/-/tree/heads%2Fmaster"
        },
        {
          "feignType": "giteeCommitVO",
          "name": "dev",
          "commitId": "def456",
          "committer": "lisi",
          "commitTime": "2026-03-10T08:30:00+08:00",
          "commitMessage": "feat: add new feature",
          "protectedBranch": false,
          "defaultBranch": false,
          "webUrl": "https://codetest.iflytek.com/osc/_source/org/my-project/-/tree/heads%2Fdev"
        }
      ]
    },
    "repoType": "GITEE"
  },
  "traceId": ""
}
```

### 脚本用法

```bash
# 通过仓库搜索关键词列出分支
python scripts/manage_branches.py list --repo-search "my-project"

# 使用直接仓库 URL 列出分支（使用仓库搜索结果中的 httpUrl）
python scripts/manage_branches.py list --repo-url "https://gitee.com/org/my-project.git"

# 使用搜索过滤和分页列出分支
python scripts/manage_branches.py list --repo-search "my-project" --search "feat" --page 1 --page-size 10
```

---

## 2. 创建分支

### 接口

```
POST /ai-code/repo/createBranch
```

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git",
  "fromBranch": "master",
  "toBranch": "feature/my-new-branch"
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL（仓库搜索结果中的 `httpUrl` 字段，以 `.git` 结尾）
- `fromBranch`（string，必填）：要基于的源分支
- `toBranch`（string，必填）：要创建的新分支名称

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

### 脚本用法

```bash
# 从 master 创建分支
python scripts/manage_branches.py create --repo-search "my-project" --from-branch "master" --to-branch "feature/my-new-branch"

# 使用直接仓库 URL 创建（使用仓库搜索结果中的 httpUrl）
python scripts/manage_branches.py create --repo-url "https://gitee.com/org/my-project.git" --from-branch "dev" --to-branch "hotfix/fix-bug"
```

---

## 3. 删除分支

### 接口

```
POST /ai-code/repo/deleteBranch
```

### 请求体

```json
{
  "repoType": "GITEE",
  "repoUrl": "https://gitee.com/org/my-project.git",
  "branchName": "feature/old-branch"
}
```

### 参数

- `repoType`（string，必填）：始终为 `"GITEE"`
- `repoUrl`（string，必填）：仓库的 HTTP 克隆 URL
- `branchName`（string，必填）：要删除的分支名称

### 成功响应

```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

### 确认工作流

删除分支操作**不可逆**。脚本强制执行两步确认流程：

**步骤 1 — 预览（不带 `--confirm`）**

不带 `--confirm` 运行时，返回 `confirmation_required` JSON 并**不执行**任何删除操作：

```json
{
  "confirmation_required": true,
  "branch_name": "feature/old-branch",
  "repo_url": "https://gitee.com/org/my-project.git",
  "message": "即将删除分支 'feature/old-branch'（仓库：https://gitee.com/org/my-project.git），此操作不可撤销，请用户确认后重新执行并附带 --confirm 参数。"
}
```

Claude 必须将此信息展示给用户，并在继续前明确请求确认。

**步骤 2 — 执行（带 `--confirm`）**

仅在用户确认后，重新运行带 `--confirm` 的命令来实际删除分支。

### 脚本用法

```bash
# 步骤 1：预览 — 输出确认提示，不执行删除
python scripts/manage_branches.py delete --repo-search "my-project" --branch-name "feature/old-branch"

# 步骤 2：执行 — 仅在用户明确确认后运行
python scripts/manage_branches.py delete --repo-search "my-project" --branch-name "feature/old-branch" --confirm

# 使用直接仓库 URL 删除（步骤 2）
python scripts/manage_branches.py delete --repo-url "https://gitee.com/org/my-project.git" --branch-name "hotfix/old-fix" --confirm
```

---

## 处理多个仓库匹配

当 `--repo-search` 匹配到多个仓库时，脚本返回退出码 1 并附带 JSON 响应列出所有匹配项。这是预期行为。

```json
{
  "multiple_repos": [
    {
      "index": 1,
      "id": 474192,
      "name": "my-project-v2",
      "path": "my-project-v2",
      "httpUrl": "https://codetest.iflytek.com/my-project-v2.git",
      "description": ""
    },
    {
      "index": 2,
      "id": 474190,
      "name": "my-project",
      "path": "my-project",
      "httpUrl": "https://codetest.iflytek.com/my-project.git",
      "description": ""
    }
  ],
  "message": "Found 2 repositories. Please select one by providing --repo-url with the httpUrl value."
}
```

将列表展示给用户，请用户通过索引选择，然后使用对应的 `httpUrl` 作为 `--repo-url`。

---

## 错误响应

所有接口的错误响应格式如下：

```json
{
  "success": false,
  "code": "500",
  "message": "错误描述",
  "data": null,
  "traceId": ""
}
```

常见错误：
- 配置缺失或无效
- 仓库未找到
- 分支未找到（无效的 `--from-branch`）
- 分支已存在（重复的 `--to-branch`）
- 权限被拒绝
- 网络连接问题
