# Gitee Management Skill - 接口返回值记录

测试仓库：sschu2 (id: 474248, httpUrl: `https://codetest.iflytek.com/sschu2/sschu2.git`)
测试时间：2026-04-08

---

## 1. 列出仓库 (list_repos.py)

**命令**：
```bash
python scripts/list_repos.py --search "sschu2"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "repoVOPage": {
      "total": 1,
      "totalPages": 1,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "feignType": "giteeProjectVO",
          "id": 474248,
          "name": "sschu2",
          "path": "sschu2",
          "description": "",
          "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/code/",
          "sshUrl": "ssh://git@codetest.iflytek.com:30004/sschu2/sschu2.git",
          "httpUrl": "https://codetest.iflytek.com/sschu2/sschu2.git",
          "fullName": "sschu2(sschu2/sschu2)",
          "fullPath": "sschu2/sschu2",
          "parentId": 2380,
          "createdTime": "2026-03-18T16:56:35+08:00",
          "ownerName": "sschu2",
          "commitNum": 0,
          "totalLines": 0
        }
      ]
    },
    "repoType": "GITEE"
  },
  "traceId": ""
}
```

---

## 2. 管理成员 (manage_members.py)

### 2a. 列出成员

**命令**：
```bash
python scripts/manage_members.py list --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --project-id 474248
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": [
    {
      "id": 388986,
      "username": "sschu2",
      "login": null,
      "name": "sschu2",
      "email": "sschu2@iflytek.com",
      "avatarUrl": null,
      "accessLevel": 8,
      "createdAt": "2026-03-18T16:56:35.31273+08:00"
    },
    {
      "id": 388988,
      "username": "minliu27",
      "login": null,
      "name": "minliu27",
      "email": "minliu27@iflytek.com",
      "avatarUrl": null,
      "accessLevel": 4,
      "createdAt": "2026-03-18T17:09:33.658+08:00"
    },
    {
      "id": 389012,
      "username": "bofeng",
      "login": null,
      "name": "bofeng",
      "email": "bofeng@iflytek.com",
      "avatarUrl": null,
      "accessLevel": 4,
      "createdAt": "2026-03-26T10:51:01.365+08:00"
    },
    {
      "id": 389088,
      "username": "changhan2",
      "login": null,
      "name": "changhan2",
      "email": "changhan2@iflytek.com",
      "avatarUrl": null,
      "accessLevel": 6,
      "createdAt": "2026-04-02T09:58:17.307+08:00"
    },
    {
      "id": 389150,
      "username": "zxke",
      "login": null,
      "name": "zxke",
      "email": "zxke@iflytek.com",
      "avatarUrl": null,
      "accessLevel": 4,
      "createdAt": "2026-04-08T10:40:11.805+08:00"
    }
  ],
  "traceId": ""
}
```

### 2b. 更新成员权限 (update)

**命令**：
```bash
python scripts/manage_members.py update --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --project-id 474248 --member "zxke" --role configurator
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 16054,
    "username": "zxke",
    "login": null,
    "name": "zxke",
    "email": "zxke@iflytek.com",
    "avatarUrl": null,
    "accessLevel": 6,
    "createdAt": "2025-02-11T10:38:09.281+08:00"
  },
  "traceId": ""
}
```

---

## 3. 管理分支 (manage_branches.py)

### 3a. 列出分支

**命令**：
```bash
python scripts/manage_branches.py list --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "branchVOPage": {
      "total": 7,
      "totalPages": 1,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "feignType": "giteeCommitVO",
          "name": "0326-branch",
          "commitId": "78884775834da3bc8cfb4dd9f66119cbfb9c237f",
          "committer": "bofeng",
          "commitTime": "2026-03-31T10:09:27+08:00",
          "commitMessage": "Merge pull request !16 from sschu2/master",
          "protectedBranch": false,
          "defaultBranch": false,
          "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/tree/heads%2F0326-branch"
        },
        {
          "feignType": "giteeCommitVO",
          "name": "master",
          "commitId": "4cf4bf99faf863d7b9bd22cd9c22a13f8287e5cb",
          "committer": "bofeng",
          "commitTime": "2026-03-26T15:47:01+08:00",
          "commitMessage": "Merge pull request !12 from sschu2/skill-br",
          "protectedBranch": false,
          "defaultBranch": true,
          "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/tree/heads%2Fmaster"
        }
      ]
    },
    "repoType": "GITEE"
  },
  "traceId": ""
}
```

> 注：以上仅展示部分分支，完整返回包含 7 个分支。

---

## 4. 管理标签 (manage_tags.py)

### 4a. 列出标签

**命令**：
```bash
python scripts/manage_tags.py list --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "tagVOPage": {
      "total": 3,
      "totalPages": 1,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "feignType": "giteeTagVO",
          "name": "feat",
          "tagMessage": "",
          "protectedTag": false,
          "commitId": "f7d6564559f4486170bca25620e3e91a1f5102e1",
          "committer": "朱玥悦",
          "commitTime": "2026-03-24T14:58:26+08:00",
          "commitMessage": "Merge pull request !7 from sschu2/skill-br"
        },
        {
          "feignType": "giteeTagVO",
          "name": "v0.2.0-master-snapshot",
          "tagMessage": "Snapshot tag from master branch",
          "protectedTag": false,
          "commitId": "86d940d6a55d4d019dd10c819b0694d5d18dbc92",
          "committer": "sschu2",
          "commitTime": "2026-03-18T17:00:16+08:00",
          "commitMessage": "feat: 添加2048游戏\n"
        },
        {
          "feignType": "giteeTagVO",
          "name": "v0.1.0-2048-game",
          "tagMessage": "Initial release of 2048 game",
          "protectedTag": false,
          "commitId": "86d940d6a55d4d019dd10c819b0694d5d18dbc92",
          "committer": "sschu2",
          "commitTime": "2026-03-18T17:00:16+08:00",
          "commitMessage": "feat: 添加2048游戏\n"
        }
      ]
    },
    "repoType": "GITEE"
  },
  "traceId": ""
}
```

---

## 5. 查询提交 (query_commits.py)

### 5a. 列出提交记录

**命令**：
```bash
python scripts/query_commits.py list --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "commitVOPage": {
      "total": 6,
      "totalPages": 1,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "type": "giteeCommitVO",
          "commitMessage": "Merge pull request !12 from sschu2/skill-br",
          "commitId": "4cf4bf99faf863d7b9bd22cd9c22a13f8287e5cb",
          "committer": "bofeng",
          "commitTime": "2026-03-26T15:47:01+08:00",
          "addition": 0,
          "deletion": 0
        },
        {
          "type": "giteeCommitVO",
          "commitMessage": "Merge pull request !8 from sschu2/revert_merge_4_skill-br_2",
          "commitId": "7b7b597fe98ef6ac2d5a87ed1d9a12dd9697c709",
          "committer": "bofeng",
          "commitTime": "2026-03-24T16:21:25+08:00",
          "addition": 0,
          "deletion": 0
        },
        {
          "type": "giteeCommitVO",
          "commitMessage": "回退 'Pull Request !4 : 1234'",
          "commitId": "f56161f3b207dc1fd521200c988e8c1a9ac0e55b",
          "committer": "bofeng",
          "commitTime": "2026-03-24T14:57:16+08:00",
          "addition": 0,
          "deletion": 0
        },
        {
          "type": "giteeCommitVO",
          "commitMessage": "Merge pull request !4 from sschu2/pr_test",
          "commitId": "ef76a0387c9be19e09354dc8c77ed30e5f9c74f1",
          "committer": "bofeng",
          "commitTime": "2026-03-24T14:04:13+08:00",
          "addition": 0,
          "deletion": 0
        },
        {
          "type": "giteeCommitVO",
          "commitMessage": "测试PR\n",
          "commitId": "cda3f5c05b07ad3ea3a51a3fa6fefb918a34f54f",
          "committer": "bofeng",
          "commitTime": "2026-03-19T13:58:01+08:00",
          "addition": 0,
          "deletion": 0
        },
        {
          "type": "giteeCommitVO",
          "commitMessage": "feat: 添加2048游戏\n",
          "commitId": "86d940d6a55d4d019dd10c819b0694d5d18dbc92",
          "committer": "sschu2",
          "commitTime": "2026-03-18T17:00:16+08:00",
          "addition": 0,
          "deletion": 0
        }
      ]
    },
    "repoType": "gitee"
  },
  "traceId": ""
}
```

### 5b. 查询提交详情

**命令**：
```bash
python scripts/query_commits.py detail --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --commit-id "4cf4bf99faf863d7b9bd22cd9c22a13f8287e5cb"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "commitDetailVO": {
      "commitId": "4cf4bf99faf863d7b9bd22cd9c22a13f8287e5cb",
      "commitTitle": null,
      "commitMessage": "Merge pull request !12 from sschu2/skill-br",
      "committer": "bofeng",
      "committerEmail": "bofeng@iflytek.com",
      "commitTime": "2026-03-26T15:47:01+08:00",
      "additions": 0,
      "deletions": 0,
      "total": 0
    },
    "repoType": "gitee",
    "commitId": "4cf4bf99faf863d7b9bd22cd9c22a13f8287e5cb",
    "repoUrl": "https://codetest.iflytek.com/sschu2/sschu2.git"
  },
  "traceId": ""
}
```

---

## 6. 管理 PR (manage_prs.py)

### 6a. 列出 PR

**命令**：
```bash
python scripts/manage_prs.py list --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git"
```

**返回值**（截取前 2 条）：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "mergeRequestPage": {
      "total": 24,
      "totalPages": 2,
      "currentPage": 1,
      "pageSize": 20,
      "data": [
        {
          "id": 285444,
          "iid": 24,
          "projectId": 474248,
          "title": "Skill test PR - auto created",
          "description": "This is an automated test PR created by skill testing",
          "state": "closed",
          "createdAt": "2026-04-08T10:42:55.082952+08:00",
          "updatedAt": "2026-04-08T10:43:20.195+08:00",
          "targetBranch": "master",
          "sourceBranch": "0326-branch",
          "authorName": "bofeng",
          "mergeStatus": "can_be_merged",
          "sha": "",
          "shouldRemoveSourceBranch": false,
          "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/24",
          "changesCount": "",
          "mergedAt": "2026-03-24T14:05:27.325144+08:00",
          "closedAt": "2026-04-08T10:43:20+08:00"
        },
        {
          "id": 285440,
          "iid": 23,
          "projectId": 474248,
          "title": "Verify fix PR - Updated",
          "description": "",
          "state": "closed",
          "createdAt": "2026-04-07T16:18:04.466763+08:00",
          "updatedAt": "2026-04-07T16:18:35.031+08:00",
          "targetBranch": "pr_test",
          "sourceBranch": "cfaedrfce",
          "authorName": "bofeng",
          "mergeStatus": "can_be_merged",
          "sha": "",
          "shouldRemoveSourceBranch": false,
          "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/23",
          "changesCount": "",
          "mergedAt": "2026-03-24T14:05:27.325144+08:00",
          "closedAt": "2026-04-07T16:18:35+08:00"
        }
      ]
    },
    "repoType": "gitee"
  },
  "traceId": ""
}
```

> 注：完整返回包含 20 条 PR（第 1 页），共 24 条。

### 6b. 创建 PR

**命令**：
```bash
python scripts/manage_prs.py create --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --source-branch "0326-branch" --target-branch "master" --title "API response test PR" --description "Testing PR creation API response"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/25",
  "traceId": ""
}
```

### 6c. PR 详情

**命令**：
```bash
python scripts/manage_prs.py detail --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --merge-request-iid 25
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 285446,
    "iid": 25,
    "projectId": 474248,
    "title": "API response test PR",
    "description": "Testing PR creation API response",
    "state": "opened",
    "createdAt": "2026-04-08T11:12:47+08:00",
    "updatedAt": "2026-04-08T11:12:47+08:00",
    "targetBranch": "master",
    "sourceBranch": "0326-branch",
    "authorName": "bofeng",
    "mergeStatus": "can_be_merged",
    "sha": "",
    "shouldRemoveSourceBranch": false,
    "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/25",
    "changesCount": "",
    "mergedAt": null,
    "closedAt": null
  },
  "traceId": ""
}
```

### 6d. 关闭 PR

**命令**：
```bash
python scripts/manage_prs.py close --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --merge-request-iid 25
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": "PR 成功关闭",
  "traceId": ""
}
```
<!-- APPEND_PLACEHOLDER_6 -->

### 6e. 更新 PR

**命令**：
```bash
python scripts/manage_prs.py update --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --merge-request-iid 26 --state-event opened --title "API test PR - Updated title"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 285448,
    "iid": 26,
    "projectId": 474248,
    "title": "API test PR - Updated title",
    "description": "",
    "state": "opened",
    "createdAt": "2026-04-08T11:13:41.7624+08:00",
    "updatedAt": "2026-04-08T11:13:52.422+08:00",
    "targetBranch": "master",
    "sourceBranch": "0326-branch",
    "authorName": "bofeng",
    "mergeStatus": "can_be_merged",
    "sha": "",
    "shouldRemoveSourceBranch": false,
    "webUrl": "https://codetest.iflytek.com/osc/_source/sschu2/sschu2/-/pull_requests/26",
    "changesCount": "",
    "mergedAt": "2026-04-08T11:13:41.7624+08:00",
    "closedAt": null
  },
  "traceId": ""
}
```

### 6f. 合并 PR (accept)

**命令**：
```bash
python scripts/manage_prs.py accept --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --merge-request-iid 26 --merge-commit-message "Test merge for API response recording"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

---

## 7. 创建仓库 (create_repo.py)

### 7a. 查询组织列表

**命令**：
```bash
python -c "import sys; sys.path.insert(0, 'scripts'); from create_repo import GiteeRepoCreator; c = GiteeRepoCreator(); r = c.list_groups(search='', page=1, per_page=5); import json; print(json.dumps(r, ensure_ascii=False, indent=2))"
```

**返回值**（截取前 2 条）：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "groupVOPage": {
      "total": 806,
      "totalPages": 162,
      "currentPage": 1,
      "pageSize": 5,
      "data": [
        {
          "feignType": "giteeGroupListVO",
          "id": "2",
          "name": "g1",
          "path": "g1",
          "description": "",
          "fullName": "",
          "fullPath": "",
          "visibility": "private",
          "avatarUrl": "",
          "webUrl": "https://codetest.iflytek.com/osc/_source/groups//-/index",
          "parentId": "0",
          "createdAt": "2022-09-15T14:18:19.758+08:00",
          "childExists": false
        },
        {
          "feignType": "giteeGroupListVO",
          "id": "6",
          "name": "jingyun-1-cs",
          "path": "jingyun-1",
          "description": "",
          "fullName": "jingyun-1-cs",
          "fullPath": "jingyun-1",
          "visibility": "private",
          "avatarUrl": "",
          "webUrl": "https://codetest.iflytek.com/osc/_source/groups/jingyun-1/-/index",
          "parentId": "0",
          "createdAt": "2022-10-19T06:51:21.674+08:00",
          "childExists": false
        }
      ]
    },
    "repoType": "GITEE"
  },
  "traceId": ""
}
```

> 注：完整返回包含 5 条组织（第 1 页），共 806 个组织。

### 7b. 创建仓库

**命令**：
```bash
python -c "import sys; sys.path.insert(0, 'scripts'); from create_repo import GiteeRepoCreator; import json; c = GiteeRepoCreator(); r = c.create_repository('api-response-test-repo-2', None, 0); print(json.dumps(r, ensure_ascii=False, indent=2))"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": {
    "id": 474294,
    "name": "api-response-test-repo-2",
    "path": "api-response-test-repo-2",
    "description": "",
    "webUrl": "https://codetest.iflytek.com/osc/_source/yyzhu4/0407-repo-3/-/code/",
    "sshUrl": null,
    "httpUrl": null,
    "namespaceId": null,
    "createdAt": "2026-04-08T11:21:24.058850725+08:00"
  },
  "traceId": ""
}
```

---

## 补充：写操作返回值汇总

### 成员管理

#### 添加成员 (add) — 用户不存在时的错误

**命令**：
```bash
python scripts/manage_members.py add --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --project-id 474248 --member "xrli34" --role collaborator
```

**返回值**：
```json
{
  "success": false,
  "code": "500",
  "message": "查询gitee用户失败",
  "data": null,
  "traceId": ""
}
```

#### 删除成员 (delete)

**命令**：
```bash
python scripts/manage_members.py delete --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --project-id 474248 --member "zxke"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

### 分支管理

#### 创建分支 (create)

**命令**：
```bash
python scripts/manage_branches.py create --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --from-branch "master" --to-branch "test/api-response-test"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

#### 删除分支 — 预览（不带 --confirm）

**命令**：
```bash
python scripts/manage_branches.py delete --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --branch-name "test/api-response-test"
```

**返回值**：
```json
{
  "confirmation_required": true,
  "branch_name": "test/api-response-test",
  "repo_url": "https://codetest.iflytek.com/sschu2/sschu2.git",
  "message": "即将删除分支 'test/api-response-test'（仓库：https://codetest.iflytek.com/sschu2/sschu2.git），此操作不可撤销，请用户确认后重新执行并附带 --confirm 参数。"
}
```

#### 删除分支 — 执行（带 --confirm）

**命令**：
```bash
python scripts/manage_branches.py delete --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --branch-name "test/api-response-test" --confirm
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

### 标签管理

#### 创建标签 (create)

**命令**：
```bash
python scripts/manage_tags.py create --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --tag-name "v0.0.1-api-test" --ref "master" --message "API response test tag"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```

#### 删除标签 (delete)

**命令**：
```bash
python scripts/manage_tags.py delete --repo-url "https://codetest.iflytek.com/sschu2/sschu2.git" --tag-name "v0.0.1-api-test"
```

**返回值**：
```json
{
  "success": true,
  "code": "200",
  "message": "success",
  "data": null,
  "traceId": ""
}
```
