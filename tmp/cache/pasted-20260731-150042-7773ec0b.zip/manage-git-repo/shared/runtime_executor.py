"""Kooky 宿主（统一 Agent）runtime 下默认解析「executor / 当前用户工号」。

与 ``shared/_skill_auth_helper.py`` 配套：当进程内已注入 kooky token（``SKILL_CRED_KOOKY_TOKEN``）
时，需要向平台 BFF 传 ``executor`` 等字段的脚本应优先由 runtime 推导，**默认不要求用户手填工号**；
仅当用户**主动声明**要用其它账号时，才以显式传入值覆盖。

本模块与 ``agents 2/test-agent`` 仓库中同名文件语义对齐，便于多 agent 复用同一约定。

解析优先级：

1. **显式参数**（如 CLI / 函数参数 ``executor``）— 用户主动指定时始终优先
2. 环境变量 ``KOOKY_USERNAME``（宿主 Gateway 注入的 ``User.username``）
3. 环境变量 ``SKILL_CRED_KOOKY_TOKEN``：按 JWT 形态**不解签**解码 payload，取 ``sub`` 作为工号

若以上皆不可用，调用方应提示用户传入工号或检查宿主侧 portal / kooky 绑定。
"""

from __future__ import annotations

import base64
import binascii
import json
import os
from typing import Any, Optional


def decode_jwt_sub_unverified(token: str) -> Optional[str]:
    """从 JWT 字符串中解码 payload 并读取 ``sub``（不校验签名，仅供 executor 推导）。"""
    raw = (token or "").strip()
    if not raw:
        return None
    parts = raw.split(".")
    if len(parts) < 2:
        return None
    payload_b64 = parts[1]
    pad = (-len(payload_b64)) % 4
    if pad:
        payload_b64 += "=" * pad
    try:
        decoded = base64.urlsafe_b64decode(payload_b64.encode("ascii"))
        data: Any = json.loads(decoded.decode("utf-8"))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError, binascii.Error):
        return None
    sub = data.get("sub") if isinstance(data, dict) else None
    if sub is None:
        return None
    s = str(sub).strip()
    return s or None


def resolve_runtime_executor(explicit: Optional[str] = None) -> Optional[str]:
    """合并显式工号与 runtime 注入，得到最终 ``executor`` 字符串或 ``None``。"""
    if explicit is not None and str(explicit).strip():
        return str(explicit).strip()

    u = os.getenv("KOOKY_USERNAME", "").strip()
    if u:
        return u

    tok = os.getenv("SKILL_CRED_KOOKY_TOKEN", "").strip()
    if tok:
        sub = decode_jwt_sub_unverified(tok)
        if sub:
            return sub

    return None
