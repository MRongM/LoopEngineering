"""
dev-assistant 认证 helper（仓库唯一副本，路径 ``dev-assistant/shared/``）。

封装 ``skill-auth-sdk`` 的入口，使各业务脚本无需感知 Mode A/B/C：

  Mode A — 宿主 runtime（``SKILL_CRED_*_TOKEN`` 等环境变量已注入）
  Mode B — 本地 + 在线网关（``KOOKY_BASE_URL`` 已设；由 skill-auth-sdk 远程拉已绑定凭证）
  Mode C — 本地 + portal OAuth（PKCE 公开客户端，浏览器跳转授权）

**依赖策略**：``skill-auth-sdk`` 仅在 **Mode B/C** 懒加载；**Mode A** 只读环境变量，
沙箱内可不安装 SDK 即可 ``import`` 本模块并取 token（与 ``agents 2/test-agent`` 对齐）。

**宿主沙箱**：Harness ``bash_tool`` 在每条命令前拼接 **``export VAR=… && <用户命令>``**，
使用户命令里的 ``cd … && python …`` 仍能继承 ``SKILL_CRED_*``。勿用单独
``python -c 'print(os.getenv(...))'`` 判断注入是否成功（易假阴性）。自检以业务脚本
``get_token()``、``python shared/_skill_auth_helper.py --source`` 或 CLI + HTTP 状态为准
（见产品文档 ``local_docs/skill-agent-credential-guide.md``）。

**多环境**：``infer_oauth_env()`` / ``get_token()`` 在无显式 ``env`` 时依次读取 ``CK_ENV``、
宿主注入的 ``PLATFORM_ENV``，使 **OAuth 端点** 与 **cyxt BFF 域名**（``portal_cyxt_origin()``）
一致，避免 dev 部署下误用 prod PKCE 缓存导致 401。

各 skill 的 ``client.py`` / 脚本在 import 本文件**之前**，须将 **含本文件** 的 ``shared/`` 目录加入 ``sys.path``（与 test-agent 相同：依次尝试向上 **2→3→4→5** 级 ``shared/``，再 ``/mnt/skills-cache/shared``、``/mnt/skills/shared``，**仅当**存在 ``_skill_auth_helper.py`` 才 insert）；再通过环境变量定制 provider 名：

    import os
    os.environ.setdefault("DEV_ASSISTANT_PROVIDER", "portal")  # 或 "gitee" / "github" ...
    from _skill_auth_helper import get_token

Provider 语义：
  - ``portal`` — 直接消费 portal access_token（适用于调 portal 自家 BFF，如 ``one.iflytek.com/cyxt`` / ``/devops``）。
    Mode B 下不会走 ``/api/v1/credentials/portal/token``（在线网关侧拒绝外发 kooky），
    而是直接用本地 portal OAuth 拿到的 access_token。
    Mode A 下除 ``SKILL_CRED_PORTAL_TOKEN`` 外，与 test-agent 一致依次接受 runtime 注入链
    （含 ``SKILL_CRED_KOOKY_TOKEN``、``OPENCLAW_SESSION_ACCESS_TOKEN``、``SKILL_ACCESS_TOKEN``）。
  - 其它 provider 名（如 ``gitee`` / ``github`` / ``jira``）— Mode A 仅 ``SKILL_CRED_{PROVIDER}_TOKEN``；
    Mode B 走 ``GET /api/v1/credentials/{PROVIDER}/token``；Mode C 仍走本模块配置的 portal OAuth 端点
    （与历史行为一致：公开客户端 PKCE）。
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# OAuth 分环境端点（与 test-agent / portal 约定一致；pre 与 test 共用 one-test）
# ---------------------------------------------------------------------------

ENV_OAUTH_CONFIG = {
    "dev": {
        "authorize_url": "https://one-dev.iflytek.com/login/oauth/authorize/",
        "token_url": "https://one-dev.iflytek.com/login/oauth/token/",
    },
    "test": {
        "authorize_url": "https://one-test.iflytek.com/login/oauth/authorize/",
        "token_url": "https://one-test.iflytek.com/login/oauth/token/",
    },
    "prod": {
        "authorize_url": "https://one.iflytek.com/login/oauth/authorize/",
        "token_url": "https://one.iflytek.com/login/oauth/token/",
    },
    "pre": {},
}
ENV_OAUTH_CONFIG["pre"] = dict(ENV_OAUTH_CONFIG["test"])

CLIENT_ID = os.getenv("DEV_ASSISTANT_OAUTH_CLIENT_ID", "skill-b")
CALLBACK_PORT = int(os.getenv("DEV_ASSISTANT_OAUTH_CALLBACK_PORT", "18090"))

# 各 skill 在 import 本模块之前 ``setdefault`` 即可定制 provider 名：
# - manage-git-repo → "gitee"
# - manage-defect-fix / manage-dev-task / manage-devops-pipeline / automate-test-handoff /
#   upload-attachment → "portal"（调 portal 自家 BFF）
PROVIDER = os.getenv("DEV_ASSISTANT_PROVIDER", "portal")

_FALSE_C_HINT_EMITTED = False


def infer_oauth_env() -> str:
    """推断 OAuth / BFF 环境键（``dev`` / ``test`` / ``pre`` / ``prod``）。

    优先 ``CK_ENV``；未设置时回退 **宿主沙箱注入的** ``PLATFORM_ENV``（与 Harness
    ``bash_tool`` 前缀对齐）。避免「BFF 已按 dev 域名、PKCE 仍走 prod 缓存」导致 401。
    """
    ck = os.getenv("CK_ENV", "").strip().lower()
    if ck in ENV_OAUTH_CONFIG:
        return ck
    pe = os.getenv("PLATFORM_ENV", "").strip().lower()
    if pe in ENV_OAUTH_CONFIG:
        return pe
    return "prod"


def portal_cyxt_origin() -> str:
    """云帆 cyxt BFF 的站点 origin（与 :func:`infer_oauth_env` 对齐）。"""
    env = infer_oauth_env()
    if env == "dev":
        return "https://one-dev.iflytek.com"
    if env in ("test", "pre"):
        return "https://one-test.iflytek.com"
    return "https://one.iflytek.com"


# 兼容旧内部名
_infer_oauth_env = infer_oauth_env


def _oauth_kwargs(env: str) -> dict[str, Any]:
    cfg = ENV_OAUTH_CONFIG[env]
    return {
        "client_id": CLIENT_ID,
        "authorize_url": cfg["authorize_url"],
        "token_url": cfg["token_url"],
        "callback_port": CALLBACK_PORT,
    }


def _token_from_env_mode_a() -> Optional[str]:
    """Mode A：读 runtime 注入的明文 token（不依赖 skill-auth-sdk）。"""
    primary_key = f"SKILL_CRED_{PROVIDER.upper()}_TOKEN"
    v = os.getenv(primary_key, "").strip()
    if v and not v.startswith("::error::"):
        return v

    if PROVIDER.strip().lower() != "portal":
        return None

    # portal：与 test-agent 一致的 runtime 注入链（BFF 常消费 kooky / 会话 token）
    for alt in (
        "SKILL_CRED_KOOKY_TOKEN",
        "SKILL_CRED_PORTAL_TOKEN",
        "OPENCLAW_SESSION_ACCESS_TOKEN",
        "SKILL_ACCESS_TOKEN",
    ):
        v2 = os.getenv(alt, "").strip()
        if v2 and not v2.startswith("::error::"):
            logger.debug("token 来源：runtime 注入 (%s)", alt)
            return v2
    return None


def detect_mode(env: str = "prod") -> str:
    """识别当前 Mode（A / B / C）。``env`` 与 token_store 策略对齐，不改变 A/B/C 判定主逻辑。"""
    if _token_from_env_mode_a():
        return "A"
    if os.getenv("KOOKY_BASE_URL", "").strip():
        return "B"
    global _FALSE_C_HINT_EMITTED
    ku = os.getenv("KOOKY_USERNAME", "").strip()
    pe = os.getenv("PLATFORM_ENV", "").strip()
    if (ku or pe) and not _FALSE_C_HINT_EMITTED:
        _FALSE_C_HINT_EMITTED = True
        logger.debug(
            "skill-auth-helper detect_mode→C：无可用 SKILL_CRED_* token，但 KOOKY_USERNAME/PLATFORM_ENV 已出现。"
            "宿主下凭证为 bash 命令前缀 ``export … &&``；勿仅凭裸 getenv 或单独 python -c 判 Mode C 并建议 pip install SDK。"
            "请以 get_token()、``python shared/_skill_auth_helper.py --source`` 或业务 client + HTTP 验证。",
        )
    return "C"


# 兼容 INSTALL.md 等文档中的一行式 ``_mode()`` 诊断（与 ``detect_mode()`` 等价）
_mode = detect_mode


def token_source(env: str = "prod") -> str:
    """返回当前 token 来源的可读描述（诊断用，绝不打印 token 内容）。"""
    primary_key = f"SKILL_CRED_{PROVIDER.upper()}_TOKEN"
    if os.getenv(primary_key, "").strip():
        return f"runtime ({primary_key})"
    if PROVIDER.strip().lower() == "portal":
        if os.getenv("SKILL_CRED_KOOKY_TOKEN", "").strip():
            return "runtime (SKILL_CRED_KOOKY_TOKEN)"
        if os.getenv("SKILL_CRED_PORTAL_TOKEN", "").strip():
            return "runtime (SKILL_CRED_PORTAL_TOKEN)"
        if os.getenv("OPENCLAW_SESSION_ACCESS_TOKEN", "").strip():
            return "session (OPENCLAW_SESSION_ACCESS_TOKEN)"
        if os.getenv("SKILL_ACCESS_TOKEN", "").strip():
            return "global (SKILL_ACCESS_TOKEN)"
    if os.getenv("KOOKY_BASE_URL", "").strip():
        return f"local-pkce + online gateway ({env})"
    return f"local-pkce ({env})"


# ---------------------------------------------------------------------------
# skill-auth-sdk：仅 Mode B/C 懒加载
# ---------------------------------------------------------------------------

_SDK_LOADED = False
_get_access_token_impl: Optional[Callable[..., str]] = None
_delete_token_impl: Optional[Callable[..., Any]] = None


def _sdk_missing_msg() -> str:
    return (
        "[skill-auth-helper] 未找到 skill_auth 包（Mode B / C 必需）。\n"
        "在宿主已注入 SKILL_CRED_*_TOKEN（Mode A）时无需安装。\n"
        "请确认 skill_auth/ 目录位于 shared/ 下或已加入 sys.path。\n"
    )


def _ensure_sdk() -> None:
    """为 Mode B/C 加载 skill_auth；失败时 stderr 说明并 raise ImportError。"""
    global _SDK_LOADED, _get_access_token_impl, _delete_token_impl
    if _SDK_LOADED:
        if _get_access_token_impl is None:
            raise ImportError(_sdk_missing_msg().strip()) from None
        return
    _SDK_LOADED = True
    try:
        from skill_auth import delete_token as _dt, get_access_token as _ga
    except ImportError as e:
        sys.stderr.write(_sdk_missing_msg())
        sys.stderr.write(f"原始错误：{e}\n")
        raise ImportError(_sdk_missing_msg().strip()) from e
    _get_access_token_impl = _ga
    _delete_token_impl = _dt


def _call_get_access_token(**kwargs: Any) -> str:
    assert _get_access_token_impl is not None
    kwargs.pop("token_store_key", None)
    kwargs.pop("allow_cross_env_token", None)
    return _get_access_token_impl(**kwargs)


def get_token(env: Optional[str] = None, *, allow_cross_env_token: bool = False) -> str:
    """三模式自动获取 access_token（业务脚本统一入口）。

    Args:
        env: OAuth 环境 ``dev`` / ``test`` / ``pre`` / ``prod``；为 ``None`` 时由
        ``CK_ENV`` 或宿主注入的 ``PLATFORM_ENV`` 推断（缺省 ``prod``）。
        allow_cross_env_token: 传给 SDK 的 PKCE 路径（若 SDK 支持），与 test-agent 语义一致。

    - Mode A → 直接读环境变量（portal 含 kooky / OpenClaw / 全局 token 链）
    - Mode B + ``PROVIDER=portal`` → 本地 portal OAuth（避开 L3 对 kooky 的拒绝）
    - Mode B + 其它 provider → ``GET /api/v1/credentials/{PROVIDER}/token``
    - Mode C → portal OAuth + PKCE（端点由 ``env`` 决定）

    异常会向上抛，由调用方 / 上层 LLM 处理（参考 SKILL.md 的 ``::error`` 输出约定）。
    """
    resolved = env if env is not None else infer_oauth_env()
    if resolved not in ENV_OAUTH_CONFIG:
        raise ValueError(f"无效的环境: {resolved}，可选值: {', '.join(ENV_OAUTH_CONFIG.keys())}")

    token_rt = _token_from_env_mode_a()
    if token_rt:
        logger.debug("token 获取：env=%s, path=runtime_injected", resolved)
        return token_rt

    mode = detect_mode(resolved)
    logger.debug("token 获取：env=%s, mode=%s", resolved, mode)

    _ensure_sdk()
    assert _get_access_token_impl is not None

    oauth_kw = _oauth_kwargs(resolved)
    return _call_get_access_token(**oauth_kw)


def invalidate_local_token(env: Optional[str] = None) -> bool:
    """清除本地缓存的 portal PKCE token。返回是否执行了删除。"""
    resolved = env if env is not None else infer_oauth_env()
    if _token_from_env_mode_a():
        return False
    _ensure_sdk()
    assert _delete_token_impl is not None
    try:
        return bool(_delete_token_impl(CLIENT_ID))
    except Exception:
        return False


def _main() -> int:
    parser = argparse.ArgumentParser(description="dev-assistant：获取 access_token（三模式自动选择）。")
    parser.add_argument(
        "--env",
        default=None,
        metavar="ENV",
        help=f"OAuth 环境（{', '.join(ENV_OAUTH_CONFIG.keys())}）；默认由 CK_ENV 或 PLATFORM_ENV 推断",
    )
    parser.add_argument("--source", action="store_true", help="只输出 token 来源（不输出 token 本身）")
    parser.add_argument("--logout", action="store_true", help="清除本地 PKCE 缓存（仅 Mode C 有效）")
    args = parser.parse_args()
    resolved = (args.env or "").strip().lower() if args.env else infer_oauth_env()
    if resolved not in ENV_OAUTH_CONFIG:
        parser.error(f"--env 必须是 {', '.join(ENV_OAUTH_CONFIG.keys())} 之一")

    if args.logout:
        cleared = invalidate_local_token(env=resolved)
        print("cleared" if cleared else "not_in_mode_c_or_no_cache")
        return 0

    if args.source:
        print(token_source(env=resolved))
        return 0

    try:
        print(get_token(env=resolved))
    except ImportError:
        return 1
    except Exception as exc:
        sys.stderr.write(f"获取 token 失败 (env={resolved}): {exc}\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(_main())
