"""
Skill Auth SDK - 统一认证 SDK

SDK 只负责认证（获取 Token），不负责业务请求。

使用方式:
    from skill_auth import get_access_token

    token = get_access_token(client_id="your-client-id")
    headers = {'Authorization': f'Bearer {token}'}
"""

from .client import get_access_token
from .oauth import authorize, exchange_code_for_token, refresh_access_token
from .token_store import get_valid_token, save_token, load_token, delete_token

__version__ = '1.0.0'

__all__ = [
    'get_access_token',
    'authorize',
    'exchange_code_for_token',
    'refresh_access_token',
    'get_valid_token',
    'save_token',
    'load_token',
    'delete_token',
]
