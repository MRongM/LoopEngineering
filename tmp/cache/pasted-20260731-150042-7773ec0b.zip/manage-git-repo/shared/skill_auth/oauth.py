#!/usr/bin/env python3
"""
OAuth 2.1 Authorization Code + PKCE 认证模块
"""

import os
import time
import secrets
import hashlib
import base64
import webbrowser
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Dict, Tuple


def _resolve_base_domain() -> str:
    ck_env = os.getenv('PLATFORM_ENV', '').strip().lower()
    if ck_env == 'dev':
        return 'https://one-dev.iflytek.com'
    if ck_env == 'test':
        return 'https://one-test.iflytek.com'
    return 'https://one.iflytek.com'


_BASE_DOMAIN = _resolve_base_domain()

DEFAULT_AUTHORIZE_URL = os.getenv('OAUTH_AUTHORIZE_URL', f'{_BASE_DOMAIN}/login/oauth/authorize/')
DEFAULT_TOKEN_URL = os.getenv('OAUTH_TOKEN_URL', f'{_BASE_DOMAIN}/login/oauth/token/')
DEFAULT_CLIENT_ID = os.getenv('OAUTH_CLIENT_ID', 'skill-b')
DEFAULT_CLIENT_SECRET = ''
DEFAULT_CALLBACK_PORT = 18090
DEFAULT_CALLBACK_PATH = '/callback'


def _get_config(client_id=None, client_secret=None, authorize_url=None, token_url=None, callback_port=None):
    """合并配置优先级：参数 > 环境变量 > 默认值"""
    return {
        'client_id': client_id or os.getenv('OAUTH_CLIENT_ID', DEFAULT_CLIENT_ID),
        'client_secret': client_secret or os.getenv('OAUTH_CLIENT_SECRET', DEFAULT_CLIENT_SECRET),
        'authorize_url': authorize_url or os.getenv('OAUTH_AUTHORIZE_URL', DEFAULT_AUTHORIZE_URL),
        'token_url': token_url or os.getenv('OAUTH_TOKEN_URL', DEFAULT_TOKEN_URL),
        'callback_port': callback_port or int(os.getenv('OAUTH_CALLBACK_PORT', str(DEFAULT_CALLBACK_PORT))),
    }


def generate_pkce_pair() -> Tuple[str, str]:
    """生成 PKCE code_verifier 和 code_challenge (S256)"""
    code_verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(code_verifier.encode('ascii')).digest()
    code_challenge = base64.urlsafe_b64encode(digest).rstrip(b'=').decode('ascii')
    return code_verifier, code_challenge


class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != DEFAULT_CALLBACK_PATH:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b'Not Found')
            return

        params = urllib.parse.parse_qs(parsed.query)
        self.server.auth_code = params.get('code', [None])[0]
        self.server.auth_state = params.get('state', [None])[0]
        self.server.auth_error = params.get('error', [None])[0]

        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()

        if self.server.auth_code:
            html = ('<!DOCTYPE html><html><head><meta charset="utf-8"><title>授权成功</title></head>'
                    '<body style="display:flex;justify-content:center;align-items:center;height:100vh;'
                    'font-family:system-ui;background:#f5f5f5"><div style="text-align:center;padding:40px;'
                    'background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.1)">'
                    '<h1 style="color:#22c55e">&#10004; 授权成功</h1>'
                    '<p style="color:#666">可以关闭此页面，返回终端继续操作。</p></div></body></html>')
        else:
            error = self.server.auth_error or '未知错误'
            html = (f'<!DOCTYPE html><html><head><meta charset="utf-8"><title>授权失败</title></head>'
                    f'<body style="display:flex;justify-content:center;align-items:center;height:100vh;'
                    f'font-family:system-ui;background:#f5f5f5"><div style="text-align:center;padding:40px;'
                    f'background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.1)">'
                    f'<h1 style="color:#ef4444">&#10008; 授权失败</h1>'
                    f'<p style="color:#666">{error}</p></div></body></html>')

        self.wfile.write(html.encode('utf-8'))

    def log_message(self, format, *args):
        pass


def exchange_code_for_token(code, code_verifier, client_id, redirect_uri,
                            client_secret=None, token_url=None) -> Dict:
    """用授权码 + PKCE code_verifier 换取 Token"""
    import requests

    cfg = _get_config(client_id=client_id, client_secret=client_secret, token_url=token_url)

    data = {
        'grant_type': 'authorization_code',
        'code': code,
        'code_verifier': code_verifier,
        'client_id': cfg['client_id'],
        'redirect_uri': redirect_uri,
    }

    response = requests.post(cfg['token_url'], data=data, headers={
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
    })
    response.raise_for_status()
    return response.json()


def refresh_access_token(refresh_token, client_id=None, client_secret=None,
                         token_url=None) -> Dict:
    """用 refresh_token 刷新 access_token"""
    import requests

    cfg = _get_config(client_id=client_id, client_secret=client_secret, token_url=token_url)

    data = {
        'grant_type': 'refresh_token',
        'refresh_token': refresh_token,
        'client_id': cfg['client_id'],
    }

    response = requests.post(cfg['token_url'], data=data, headers={
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
    })
    response.raise_for_status()
    return response.json()


def authorize(client_id=None, client_secret=None, authorize_url=None,
              token_url=None, callback_port=None, timeout=120) -> Dict:
    """执行完整的 OAuth 2.1 Authorization Code + PKCE 授权流程"""
    cfg = _get_config(client_id=client_id, client_secret=client_secret,
                      authorize_url=authorize_url, token_url=token_url,
                      callback_port=callback_port)

    if not cfg['client_id']:
        raise ValueError("OAuth Client ID 未配置。请设置环境变量 OAUTH_CLIENT_ID 或传入 client_id 参数。")

    code_verifier, code_challenge = generate_pkce_pair()
    state = secrets.token_urlsafe(32)

    server = HTTPServer(('127.0.0.1', cfg['callback_port']), _OAuthCallbackHandler)
    server.auth_code = None
    server.auth_state = None
    server.auth_error = None
    server.timeout = 1

    redirect_uri = f"http://127.0.0.1:{cfg['callback_port']}{DEFAULT_CALLBACK_PATH}"

    print(f"\n{'=' * 60}")
    print("[OAuth] 启动授权流程...")
    print(f"[OAuth] 回调地址: {redirect_uri}")
    print(f"{'=' * 60}")

    params = {
        'response_type': 'code',
        'client_id': cfg['client_id'],
        'redirect_uri': redirect_uri,
        'code_challenge': code_challenge,
        'code_challenge_method': 'S256',
        'state': state,
    }
    auth_url = f"{cfg['authorize_url']}?{urllib.parse.urlencode(params)}"

    print(f"\n[OAuth] 正在打开浏览器进行授权...")
    print(f"[OAuth] 如果浏览器未自动打开，请手动访问：")
    print(f"  {auth_url}\n")

    webbrowser.open(auth_url)

    print(f"[OAuth] 等待授权完成（超时: {timeout}秒）...")
    start_time = time.time()

    try:
        while time.time() - start_time < timeout:
            server.handle_request()
            if server.auth_code is not None or server.auth_error is not None:
                break
        else:
            raise TimeoutError(f"授权超时（{timeout}秒）。请重试。")
    finally:
        server.server_close()

    if server.auth_error:
        raise RuntimeError(f"授权失败: {server.auth_error}")
    if not server.auth_code:
        raise RuntimeError("未收到授权码")
    if server.auth_state != state:
        raise RuntimeError("State 不匹配，可能存在 CSRF 攻击。")

    print("[OAuth] 授权码已收到，正在换取 Token...")

    token_response = exchange_code_for_token(
        code=server.auth_code,
        code_verifier=code_verifier,
        client_id=cfg['client_id'],
        redirect_uri=redirect_uri,
        client_secret=cfg['client_secret'],
        token_url=cfg['token_url'],
    )

    print("[OAuth] Token 获取成功！")
    return token_response
