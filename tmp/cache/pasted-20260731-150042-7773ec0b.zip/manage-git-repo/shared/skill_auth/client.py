#!/usr/bin/env python3
"""
Token 获取的便捷封装

SDK 只负责认证（获取 Token），不负责业务请求。
业务 Skill 拿到 Token 后自行决定怎么发请求、往哪发。

使用方式:
    from skill_auth import get_access_token

    token = get_access_token(client_id="skill-b")
    # 业务 Skill 自行用 token 发请求
    headers = {'Authorization': f'Bearer {token}'}
    response = requests.post(url, json=data, headers=headers)
"""

from .token_store import get_valid_token


def get_access_token(client_id=None, client_secret=None,
                     authorize_url=None, token_url=None,
                     callback_port=None) -> str:
    """
    获取有效的 access_token（SDK 对外的核心方法）

    自动处理：全局 Token → 本地缓存 Token → OAuth 授权

    Args:
        client_id: OAuth Client ID（可选，默认从环境变量）
        client_secret: OAuth Client Secret（可选）
        authorize_url: OAuth 授权端点（可选，默认 one.iflytek.com）
        token_url: OAuth Token 端点（可选）
        callback_port: 本地回调端口（可选，默认 18090）

    Returns:
        有效的 access_token 字符串
    """
    return get_valid_token(
        client_id=client_id,
        client_secret=client_secret,
        authorize_url=authorize_url,
        token_url=token_url,
        callback_port=callback_port,
    )
