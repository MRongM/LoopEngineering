#!/usr/bin/env python3
"""
Token 本地存储与自动刷新模块

存储路径: ~/.skill-auth/tokens/{client_id}.json
文件权限: 600（仅所有者可读写）
"""

import os
import sys
import json
import time
import stat
from typing import Optional, Dict
from pathlib import Path

from . import oauth

TOKEN_STORE_DIR = Path.home() / '.skill-auth' / 'tokens'
REFRESH_BUFFER_SECONDS = 60


def _get_token_path(client_id: str) -> Path:
    safe_name = "".join(c if c.isalnum() or c in '-_' else '_' for c in client_id)
    return TOKEN_STORE_DIR / f"{safe_name}.json"


def _ensure_store_dir():
    TOKEN_STORE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(TOKEN_STORE_DIR, stat.S_IRWXU)
    except OSError:
        pass


def save_token(client_id: str, token_data: Dict) -> None:
    """保存 Token 到本地文件"""
    _ensure_store_dir()

    store_data = {
        'access_token': token_data.get('access_token'),
        'refresh_token': token_data.get('refresh_token'),
        'token_type': token_data.get('token_type', 'Bearer'),
        'expires_in': token_data.get('expires_in'),
        'expires_at': time.time() + token_data.get('expires_in', 3600),
        'saved_at': time.time(),
        'client_id': client_id,
    }

    token_path = _get_token_path(client_id)
    with open(token_path, 'w') as f:
        json.dump(store_data, f, indent=2)

    try:
        os.chmod(token_path, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def load_token(client_id: str) -> Optional[Dict]:
    """从本地文件加载 Token"""
    token_path = _get_token_path(client_id)
    if not token_path.exists():
        return None
    try:
        with open(token_path, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return None


def delete_token(client_id: str) -> bool:
    """删除本地存储的 Token"""
    token_path = _get_token_path(client_id)
    if token_path.exists():
        token_path.unlink()
        return True
    return False


def is_token_expired(token_data: Dict) -> bool:
    """检查 Token 是否已过期（含缓冲时间）"""
    expires_at = token_data.get('expires_at', 0)
    return time.time() >= (expires_at - REFRESH_BUFFER_SECONDS)


def get_valid_token(client_id=None, client_secret=None,
                    authorize_url=None, token_url=None,
                    callback_port=None) -> str:
    """
    获取有效的 access_token（核心方法）

    检查顺序：
    0. 检查全局环境变量 SKILL_ACCESS_TOKEN（云端平台场景）
    1. 从本地加载已存储的 Token
    2. 如果 Token 未过期，直接返回
    3. 如果 Token 已过期但有 refresh_token，尝试刷新
    4. 如果刷新失败或无 Token，发起完整 OAuth 授权流程
    """
    global_token = os.getenv('SKILL_ACCESS_TOKEN')
    if global_token:
        return global_token

    cfg = oauth._get_config(client_id=client_id, client_secret=client_secret,
                            authorize_url=authorize_url, token_url=token_url,
                            callback_port=callback_port)
    cid = cfg['client_id']

    if not cid:
        raise ValueError("OAuth Client ID 未配置。请设置环境变量 OAUTH_CLIENT_ID。")

    token_data = load_token(cid)

    if token_data:
        if not is_token_expired(token_data):
            return token_data['access_token']

        refresh_token = token_data.get('refresh_token')
        if refresh_token:
            try:
                print("[Token] Access Token 已过期，正在刷新...")
                new_token_data = oauth.refresh_access_token(
                    refresh_token=refresh_token,
                    client_id=cid,
                    client_secret=cfg['client_secret'],
                    token_url=cfg['token_url'],
                )
                save_token(cid, new_token_data)
                print("[Token] Token 刷新成功！")
                return new_token_data['access_token']
            except Exception as e:
                print(f"[Token] 刷新失败 ({e})，将重新授权...", file=sys.stderr)

    print("[Token] 需要进行 OAuth 授权...")
    token_response = oauth.authorize(
        client_id=cid,
        client_secret=cfg['client_secret'],
        authorize_url=cfg['authorize_url'],
        token_url=cfg['token_url'],
        callback_port=cfg['callback_port'],
    )
    save_token(cid, token_response)
    return token_response['access_token']
